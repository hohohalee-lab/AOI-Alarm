# AOI 알람 — 폰 홈 화면 앱 + 텔레그램 팝업

- **앱**: 폰 홈 화면에 설치되는 웹앱(PWA). 종목별 상태(보유/현금 대기), **다음 알람까지 남은 거리**, 지표 현황, 알람 이력, 안내.
- **팝업 알람**: 텔레그램으로 전송(폰 잠금화면에 팝업). 매일 한국시간 09:10경 GitHub 무료 서버가 자동 계산.
- 관심종목은 저장소의 `watchlist.json`에 있는 종목만. 알람 이력은 `state/aoi.db`와 앱의 "이력" 탭에 저장.

## 설치 순서 (폰만으로 가능, 한 번만)

### 1. 텔레그램 봇 만들기
1. 텔레그램에서 **@BotFather** 검색 → `/newbot` → 이름, 아이디(끝이 `bot`) 입력 → 알려주는 **토큰**(`123456:ABC...`)을 길게 눌러 복사해 메모 앱에 붙여둡니다.
2. 만든 봇을 열고 **시작(Start)** → 아무 글자나 전송.
3. **@userinfobot** 을 열고 시작 → `Id: 123456789` 의 숫자가 **채팅 ID**입니다(메모해 둠).

### 2. GitHub 저장소 만들기 (폴더 업로드 없음)
1. 폰 브라우저에서 github.com 로그인 → `github.com/new`
2. 이름 `aoi-alarm`, **Public**, **Add a README file 체크** → Create repository.
3. 저장소 화면에서 **Add file → Upload files** → 이 `aoi_alarm.zip` **압축을 풀지 말고 그대로** 선택 → Commit changes.
4. **Add file → Create new file** → 파일 이름 칸에 `.github/workflows/daily.yml` 입력(슬래시를 치면 폴더가 만들어집니다) → 내용에 **`ci/daily.yml` 의 내용 전체를 붙여넣기** → Commit changes.
   (압축 안의 `ci/daily.yml`, 또는 채팅에 있는 같은 내용)

### 3. 비밀값 등록
저장소 **Settings → Secrets and variables → Actions → New repository secret**
- `TELEGRAM_BOT_TOKEN` : 1단계 토큰 / `TELEGRAM_CHAT_ID` : 1단계 숫자

### 4. 첫 실행과 앱 주소 켜기
1. **Actions** 탭 → (처음이면 "enable" 클릭) → aoi-alarm → **Run workflow** → `텔레그램 테스트 알림 보내기` 체크 → Run. 1~2분 뒤 텔레그램에 테스트 알림이 오고 초록 체크가 뜨면 성공입니다.
2. **Settings → Pages → Source: Deploy from a branch → `main` / `/docs` → Save.**
3. 주소: `https://<내 GitHub 아이디>.github.io/aoi-alarm/` (1~2분 뒤)

설정 화면이 안 보이면 Chrome 메뉴에서 "데스크톱 사이트"를 켜세요.

### 5. 폰에 앱 설치 (안드로이드)
Chrome에서 위 주소 → **⋮ → 앱 설치**(또는 홈 화면에 추가). 텔레그램 알림 권한도 켜 두세요.

## 관심종목 바꾸기
앱 "안내" 탭의 **관심종목 편집 열기** 버튼 → 저장소 루트의 `watchlist.json`에서 종목 추가/삭제 → Commit. 다음 실행부터 적용됩니다.
`"holding": true`는 지금 보유 중(다음 신호는 매도), `false`는 현금 대기(다음 신호는 재진입, `"sold_on": "2026-11-05"`로 매도일 지정 가능).
**검증된 종목**: ETH XRP ADA LINK DOGE SOL AVAX NEAR SUI ONDO. 그 밖의 종목은 "⚠검증 대상 외"로 표시됩니다.

## 알람 분류
| 분류 | 알림 제목 | 의미 | 근거 |
|---|---|---|---|
| 🔻 매도 / 🔼 재진입 | 매도·재진입형 | 종가가 EMA20 아래 이탈 → 매도, 20일 최고 종가 돌파 + BTC>EMA20 → 재진입(60일 지나면 시간 만료 재진입) | 사전 기준 통과, 체결 지연에 민감 |
| 🚪 매도 경고 | 매도전용형(참고용) | EMA50/100 이탈 등 중장기 추세 이탈 + 시장 약세 3개 중 2개 이상. 재진입 알람 없음 | 약한 근거 |
근거와 확률은 `results/REPORT.md`.

## 동작 규칙
- 마감된 일봉만 사용. 지표는 신호일까지의 데이터만 사용(미래 봉을 잘라 재계산해 동일함을 검증).
- 처음에는 직전 봉만 평가(알람 폭주 없음). 며칠 빠졌으면 순서대로 따라잡고 "(지연 발송)" 표시.
- 같은 알람은 한 번만 저장·발송. 발송 실패는 다음 실행에서 재시도.
- 앱 상단에 갱신이 36시간 넘게 지났다는 경고가 뜨면 자동 실행이 멈춘 것입니다.

## PC/서버에서 직접 돌리기(선택)
`pip install -r requirements.txt` → `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` 환경변수 → `python -m aoi.app test-notify` → `python -m aoi.app run`. 매일 `10 0 * * *`(UTC)에 cron. 정시성이 중요하면 GitHub 스케줄(수 분~수십 분 지연 가능)보다 이쪽이 낫습니다.
명령: `run` · `history -n 30` · `status` · `replay --from 2026-09-01 --symbols ONDO --print`(네트워크 불필요).
테스트: `python tests/test_equivalence.py`, `python tests/test_stack_mock.py`.

## 한계 (꼭 읽기)
- **실제 Coinbase·텔레그램·GitHub Actions·GitHub Pages 연결은 개발 환경에서 접근이 막혀 시험하지 못했습니다.** 가짜 서버와 에뮬레이션 폰으로만 확인했습니다. 5단계 테스트가 첫 실전 확인입니다.
- 이 앱은 알림만 보냅니다. 주문하지 않습니다. 가격은 Coinbase USD 기준이라 국내 거래소 KRW 가격·수수료와 다릅니다.
- 과거 성과는 미래를 보장하지 않으며 투자 조언이 아닙니다.
