"""App alerts must equal the validated research logic (cycle simulator for B, event list for A)."""
import os, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np, pandas as pd
from aoi import engine, cycle as CY, signals as S, products as P
from aoi.store import Store

cl = pd.read_csv(os.path.join(os.path.dirname(__file__), '..', 'data', 'closes.csv'), index_col=0, parse_dates=True)
COINS = ['ETH','XRP','ADA','LINK','DOGE','SOL','AVAX','NEAR','SUI','ONDO']
feats, conds = engine.compute({k: cl[k].dropna() for k in COINS + ['BTC']}, COINS)
latest = cl.BTC.index.max()

def check_B(start):
    bad = 0; tot = 0
    for k in COINS:
        st = max(pd.Timestamp(start), feats[k].index[0] + pd.Timedelta(days=200))
        sim = CY.simulate(feats[k]['c'], S.composite(conds[k], P.B_SELL), S.composite(conds[k], P.B_REBUY), st, latest, timeout=P.B_TIMEOUT_DAYS, min_out=P.B_MIN_OUT_DAYS)
        ch = sim.pos.diff().fillna(0); exp = [(d, 'SELL' if v < 0 else 'BUY') for d, v in ch.items() if v != 0]
        store = Store(os.path.join(tempfile.mkdtemp(), 'x.db'))
        engine.init_state(store, dict(symbol=k, holding=True), st)           # state IN at the first simulated day
        al = engine.process_symbol(k, feats[k], conds[k], store, st, latest, latest, True)
        got = [(pd.Timestamp(a['candle_date']), a['action']) for a in al if a['category'] == 'B']
        tot += 1; ok = got == exp; bad += (not ok)
        if not ok: print('B MISMATCH', k, 'expected', exp[:4], 'got', got[:4], len(exp), len(got))
    return tot, bad

def check_A(start):
    bad = 0
    for k in COINS:
        st = pd.Timestamp(start)
        lv = engine.a_level(conds[k])
        exp = [d for d in S.events(lv.loc[st - pd.Timedelta(days=1):], P.A_COOLDOWN_DAYS) if d >= st and d >= feats[k].index[P.MIN_HISTORY_BARS]]
        store = Store(os.path.join(tempfile.mkdtemp(), 'x.db')); engine.init_state(store, dict(symbol=k, holding=True), st - pd.Timedelta(days=1))
        al = engine.process_symbol(k, feats[k], conds[k], store, st - pd.Timedelta(days=1), latest, latest, True)
        got = [pd.Timestamp(a['candle_date']) for a in al if a['category'] == 'A']
        if got != exp: bad += 1; print('A MISMATCH', k, [str(x.date()) for x in exp[:5]], [str(x.date()) for x in got[:5]])
    return len(COINS), bad

if __name__ == '__main__':
    for s in ('2023-06-01', '2025-01-01'):
        t, b = check_B(s); print(f'B vs simulate from {s}: coins {t}, mismatches {b}')
    t, b = check_A('2023-06-01'); print(f'A vs research events: coins {t}, mismatches {b}')
