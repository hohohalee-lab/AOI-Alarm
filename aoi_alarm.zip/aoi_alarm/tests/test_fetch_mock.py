"""Mock Binance/OKX/Upbit servers (response formats as documented) -> run fetch_ohlcv.py end to end."""
import os, sys, json, threading, subprocess, tempfile, time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import pandas as pd
H4 = 4 * 3600 * 1000; T0 = int(pd.Timestamp('2024-01-01', tz='UTC').timestamp() * 1000); N = 2500
def bar(i): p = 100 + i * 0.01; return p, p + 1, p - 1, p + 0.5, 10 + i % 7
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query); out = []
        if u.path == '/api/v3/klines':
            if q['symbol'][0] == 'AXLUSDT': self.send_response(400); self.end_headers(); self.wfile.write(b'{"code":-1121}'); return
            t = int(q['startTime'][0]); lim = int(q['limit'][0]); i0 = max(0, (t - T0 + H4 - 1) // H4)
            for i in range(i0, min(N, i0 + lim)): o, h, l, c, v = bar(i); out.append([T0 + i * H4, str(o), str(h), str(l), str(c), str(v), 0, '0', 0, '0', '0', '0'])
        elif u.path == '/api/v5/market/history-candles':
            a = int(q['after'][0]); idx = [i for i in range(N) if T0 + i * H4 < a][::-1][:100]
            out = {'code': '0', 'data': [[str(T0 + i * H4), *[str(x) for x in bar(i)[:4]], str(bar(i)[4]), '0', '0', '1'] for i in idx]}
        elif u.path.startswith('/v1/candles/minutes/240'):
            to = pd.Timestamp(q['to'][0]) if 'to' in q else pd.Timestamp('2099-01-01'); cnt = int(q['count'][0])
            idx = [i for i in range(N) if pd.Timestamp(T0 + i * H4, unit='ms') < to][::-1][:cnt]
            out = [dict(candle_date_time_utc=pd.Timestamp(T0 + i * H4, unit='ms').strftime('%Y-%m-%dT%H:%M:%S'), opening_price=bar(i)[0] * 1400, high_price=bar(i)[1] * 1400, low_price=bar(i)[2] * 1400, trade_price=bar(i)[3] * 1400, candle_acc_trade_volume=bar(i)[4]) for i in idx]
        self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(json.dumps(out).encode())
srv = HTTPServer(('127.0.0.1', 0), H); port = srv.server_port; threading.Thread(target=srv.serve_forever, daemon=True).start()
tmp = tempfile.mkdtemp(); here = os.path.dirname(os.path.abspath(__file__))
env = dict(os.environ, BINANCE_BASES=f'http://127.0.0.1:1,http://127.0.0.1:{port}', OKX_BASE=f'http://127.0.0.1:{port}', UPBIT_BASE=f'http://127.0.0.1:{port}', OUT_DIR=tmp, SINCE='2024-01-01', COINS='BTC,AXL', RETRY_SLEEP='0', PAUSE='0')
r = subprocess.run([sys.executable, os.path.join(here, '..', 'research', 'fetch_ohlcv.py')], env=env, capture_output=True, text=True, timeout=900)
print(r.stdout[-600:], r.stderr[-300:])
D = pd.read_csv(os.path.join(tmp, 'ohlcv_4h.csv.gz'), parse_dates=['open_time_utc'])
ok = []
def check(n, c): ok.append(c); print('PASS' if c else 'FAIL', n)
b = D[(D.source == 'binance_usdt') & (D.symbol == 'BTC')]; check('binance BTC all %d bars, no dups, strictly 4h' % N, len(b) == N and b.open_time_utc.is_unique and (b.open_time_utc.diff().dropna() == pd.Timedelta(hours=4)).all())
check('binance first bar values', abs(b.iloc[0].open - 100) < 1e-9 and abs(b.iloc[5].volume - (10 + 5 % 7)) < 1e-9)
u = D[(D.source == 'upbit_krw') & (D.symbol == 'BTC')]; check('upbit BTC all bars, KRW scale, ordered', len(u) == N and u.open_time_utc.is_monotonic_increasing and abs(u.iloc[0].open - 140000) < 1)
x = D[(D.symbol == 'AXL') & (D.source == 'okx_usdt')]; check('binance failure falls back to OKX (AXL)', len(x) == N)
check('coverage file written', os.path.exists(os.path.join(tmp, 'coverage.txt')))
print('ALL PASSED' if all(ok) else 'FAILURES'); sys.exit(0 if all(ok) else 1)
