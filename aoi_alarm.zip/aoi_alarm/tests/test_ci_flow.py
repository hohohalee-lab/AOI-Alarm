"""Simulates the phone setup: repo root holds ONLY aoi_alarm.zip (+ pasted workflow). Runs the same commands the workflow runs."""
import os, sys, json, subprocess, tempfile, shutil, zipfile, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
spec = importlib.util.spec_from_file_location('sm', os.path.join(HERE, 'test_stack_mock.py'))
# reuse the mock servers without running its test body: import pieces by exec of the top part
src = open(os.path.join(HERE, 'test_stack_mock.py'), encoding='utf-8').read().split("tmp = tempfile.mkdtemp()")[0]
ns = {'__file__': os.path.join(HERE, 'test_stack_mock.py')}; exec(src, ns)
STATE, base = ns['STATE'], ns['base']
ws = tempfile.mkdtemp(); zp = os.path.join(ws, 'aoi_alarm.zip')
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED) as z:
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = [d for d in dn if d not in ('__pycache__', '.git')]
        for f in fn:
            full = os.path.join(dp, f); rel = os.path.relpath(full, os.path.dirname(ROOT))
            if rel.endswith('aoi.db'): continue
            z.write(full, rel)
json.dump(dict(watchlist=[dict(symbol='ONDO', holding=True), dict(symbol='SOL', holding=True)], notify=dict(channels=['telegram']), coinbase_base_url=base, coinbase_pause=0), open(os.path.join(ws, 'watchlist.json'), 'w'))
env = dict(os.environ, GITHUB_WORKSPACE=ws, TELEGRAM_BOT_TOKEN='T', TELEGRAM_CHAT_ID='1', TELEGRAM_API_BASE=base, TEST_NOTIFY='true')
def step(cmd):
    r = subprocess.run(cmd, shell=True, cwd=ws, env=env, capture_output=True, text=True)
    if r.returncode: print(r.stdout[-1500:], r.stderr[-1500:]); sys.exit('FAILED: ' + cmd)
    return r.stdout
def ok(n, c):
    print(('PASS ' if c else 'FAIL ') + n)
    if not c: sys.exit(1)
# pip install is skipped offline-safe: packages already present
step('unzip -qo aoi_alarm.zip -d _app'); env['PIP_NO_INDEX'] = '1'
STATE['until'] = '2026-10-05'; step('bash _app/aoi_alarm/ci/run.sh')
ok('test notification sent', any('AOI' in t['text'][0] for t in STATE['tg']))
ok('repo root now has docs/, state/, watchlist.json (and still the zip)', all(os.path.exists(os.path.join(ws, p)) for p in ['docs/index.html', 'docs/sw.js', 'docs/manifest.webmanifest', 'docs/data/status.json', 'state/aoi.db', 'watchlist.json', 'aoi_alarm.zip']))
STATE['until'] = '2026-10-31'; env['TEST_NOTIFY'] = 'false'; n0 = len(STATE['tg']); step('bash _app/aoi_alarm/ci/run.sh')
st = json.load(open(os.path.join(ws, 'docs/data/status.json'), encoding='utf-8')); hi = json.load(open(os.path.join(ws, 'docs/data/history.json'), encoding='utf-8'))
ok('catch-up pushed alerts and app data lists them', len(STATE['tg']) - n0 == len(hi['alerts']) >= 4 and sorted(s['symbol'] for s in st['symbols']) == ['ONDO', 'SOL'])
n1 = len(STATE['tg']); step('bash _app/aoi_alarm/ci/run.sh'); ok('second run same day is idempotent (state persisted in state/)', len(STATE['tg']) == n1)
# the "Save" step must commit only user-level files, never _app
step('git init -q -b main && git config user.email a@b.c && git config user.name t')
step('git add watchlist.json docs state aoi_alarm.zip && git commit -qm init'); tracked = step('git ls-files')
ok('git tracks watchlist.json, docs/, state/ but not _app/', 'state/aoi.db' in tracked and 'watchlist.json' in tracked and '_app' not in tracked)
print('CI FLOW OK; files in repo root:', sorted(os.listdir(ws)))
