"""End-to-end: fake Coinbase + Telegram + ntfy HTTP servers; exercises fetch -> signals -> store -> notify -> viewer."""
import os, sys, json, threading, tempfile, re, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import pandas as pd
from aoi import app, notify
from aoi.store import Store

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
CL = pd.read_csv(os.path.join(ROOT, 'data', 'closes.csv'), index_col=0, parse_dates=True)
STATE = dict(until='2026-10-05', tg=[], ntfy=[], tg_fail=False, ntfy_fail=False, candle_calls=0)

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        u = urllib.parse.urlparse(self.path); m = re.match(r'/products/([A-Z]+)-USD/candles', u.path); q = urllib.parse.parse_qs(u.query)
        if not m or m.group(1) not in CL.columns: self.send_response(404); self.end_headers(); return
        STATE['candle_calls'] += 1
        s = CL[m.group(1)].dropna().loc[:STATE['until']]
        a = pd.Timestamp(q['start'][0]).tz_localize(None); b = pd.Timestamp(q['end'][0]).tz_localize(None)
        s = s[(s.index >= a) & (s.index <= b)].iloc[::-1].iloc[:300]
        rows = [[int(t.timestamp()), v, v, v, v, 1.0] for t, v in s.items()]
        body = json.dumps(rows).encode(); self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(body)
    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0)); body = self.rfile.read(n).decode()
        if '/sendMessage' in self.path:
            if STATE['tg_fail']: self.send_response(500); self.end_headers(); return
            STATE['tg'].append(urllib.parse.parse_qs(body)); self.send_response(200); self.end_headers(); self.wfile.write(b'{"ok":true,"result":{}}')
        else:
            if STATE['ntfy_fail']: self.send_response(500); self.end_headers(); return
            STATE['ntfy'].append((self.path, dict(self.headers), body)); self.send_response(200); self.end_headers(); self.wfile.write(b'{}')

srv = ThreadingHTTPServer(('127.0.0.1', 0), H); port = srv.server_address[1]; threading.Thread(target=srv.serve_forever, daemon=True).start()
base = f'http://127.0.0.1:{port}'
tmp = tempfile.mkdtemp()
cfg = dict(watchlist=[dict(symbol='ondo', holding=True), dict(symbol='SOL', holding=True), dict(symbol='ETH', holding=True)], notify=dict(channels=['telegram', 'ntfy']),
           db_path=os.path.join(tmp, 'a.db'), docs_dir=os.path.join(tmp, 'docs'), coinbase_base_url=base, coinbase_pause=0)
json.dump(cfg, open(os.path.join(tmp, 'cfg.json'), 'w'))
os.environ.update(TELEGRAM_BOT_TOKEN='TKN', TELEGRAM_CHAT_ID='42', TELEGRAM_API_BASE=base, NTFY_TOPIC='my-secret-topic', NTFY_SERVER=base)
# app resolves db/viewer relative to ROOT; absolute paths pass through os.path.join
def run(): app.main(['--config', os.path.join(tmp, 'cfg.json'), 'run'])

def check(name, cond):
    print(('PASS ' if cond else 'FAIL ') + name); 
    if not cond: sys.exit(1)

STATE['until'] = '2026-10-05'; run()
n1 = len(STATE['tg'])
check('run1 (first run) evaluates only the latest candle -> no flood', n1 <= 1)
STATE['until'] = '2026-10-31'; run()
st = Store(cfg['db_path']); hist = st.history()
syms = sorted({(a['symbol'], a['category'], a['action'], a['candle_date']) for a in hist})
print('  alerts after catch-up:', syms)
check('run2 caught up missed days with alerts', len(hist) >= 4)
check('every alert delivered to BOTH channels', len(STATE['tg']) - n1 == len(hist) - n1 and len(STATE['ntfy']) == len(STATE['tg']))
check('late flag set for catch-up alerts', all(a['late'] == 1 for a in hist if a['candle_date'] < '2026-10-31'))
check('telegram payload has chat id and HTML title', STATE['tg'][-1]['chat_id'] == ['42'] and STATE['tg'][-1]['text'][0].startswith('<b>'))
check('ntfy topic path + RFC2047 title header + urgent priority', STATE['ntfy'][-1][0] == '/my-secret-topic' and STATE['ntfy'][-1][1].get('Title', '').startswith('=?UTF-8?B?') and STATE['ntfy'][-1][1].get('Priority') in ('4', '5'))
before = (len(STATE['tg']), len(STATE['ntfy']), len(hist)); run()
check('run3 same data is idempotent (no duplicate alerts or pushes)', (len(STATE['tg']), len(STATE['ntfy']), len(Store(cfg['db_path']).history())) == before)
hj = json.load(open(os.path.join(tmp, 'docs', 'data', 'history.json'), encoding='utf-8')); sj = json.load(open(os.path.join(tmp, 'docs', 'data', 'status.json'), encoding='utf-8'))
check('app data json written (history + status for every watchlist symbol)', len(hj['alerts']) == len(hist) and sorted(x['symbol'] for x in sj['symbols']) == ['ETH', 'ONDO', 'SOL'] and all('next' in x for x in sj['symbols']))
check('symbols are upper-cased from config', all(a['symbol'] in ('ONDO', 'SOL', 'ETH') for a in hist))
# delivery failure + retry
STATE['tg_fail'] = STATE['ntfy_fail'] = True
s2 = Store(cfg['db_path']); aid = s2.add_alert(dict(candle_date='2026-11-01', symbol='ETH', category='B', action='SELL', price=1.0, title='T', body='B', indicators={}, late=False))
ch = notify.build(cfg['notify']); app.deliver(s2, ch)
check('all channels failing keeps alert pending with error recorded', any(p['id'] == aid for p in s2.pending()) and 'telegram' in (s2.pending()[0]['delivery_error'] or ''))
STATE['tg_fail'] = False; app.deliver(s2, ch)
check('retry later delivers pending alert once one channel recovers', not any(p['id'] == aid for p in s2.pending()))
print('candle HTTP calls total:', STATE['candle_calls'])
print('ALL STACK TESTS PASSED')
