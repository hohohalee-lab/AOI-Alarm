"""Condition registry. Each condition: f(df) -> boolean Series (level, or one-day pulse for crosses).
Roles: setup (recent overheating), trigger (pulse/level), market (context), rebuy (re-entry)."""
import numpy as np
import pandas as pd

def recent(s, n):
    return s.fillna(False).astype(float).rolling(n, min_periods=1).max().eq(1)

def cross_dn(a, b):
    return (a < b) & (a.shift() >= b.shift())

def cross_up(a, b):
    return (a > b) & (a.shift() <= b.shift())

def edge(s):
    s = s.fillna(False)
    return s & ~s.shift(fill_value=False)

C = {}   # name -> (role, korean label, fn)
def reg(name, role, label):
    def deco(fn):
        C[name] = (role, label, fn); return fn
    return deco

# ---- setups: overheating seen within last 14 days
@reg('s_rsi_hot', 'setup', 'RSI14 70 이상 (최근 14일)')
def _(d): return recent(d.rsi >= 70, 14)
@reg('s_ext20', 'setup', 'SMA20 이격 +15% 이상 (최근 14일)')
def _(d): return recent(d.dist20 >= .15, 14)
@reg('s_bb_out', 'setup', '볼린저 상단 이탈 (최근 14일)')
def _(d): return recent(d.c > d.bb_up, 14)
@reg('s_roc_hot', 'setup', '30일 상승률 상위10% (최근 14일)')
def _(d): return recent(d.roc30_pct >= .9, 14)
@reg('s_vol_hot', 'setup', '변동성 상위10% (최근 14일)')
def _(d): return recent(d.rv_pct >= .9, 14)
@reg('s_new_high', 'setup', '60일 신고가 (최근 10일)')
def _(d): return recent(d.c >= d.hh60, 10)

# ---- triggers (sell): momentum fade / price break
@reg('t_rsi_fall70', 'trigger', 'RSI 70 하향 이탈')
def _(d): return (d.rsi < 70) & (d.rsi.shift() >= 70)
@reg('t_bb_reenter', 'trigger', '볼린저 상단 재진입')
def _(d): return (d.c <= d.bb_up) & (d.c.shift() > d.bb_up.shift())
@reg('t_macd_dn', 'trigger', 'MACD 히스토그램 음전환')
def _(d): return (d.macd_hist < 0) & (d.macd_hist.shift() >= 0)
@reg('t_ema10_dn', 'trigger', '종가 EMA10 하향 이탈')
def _(d): return cross_dn(d.c, d.ema10)
@reg('t_ema20_dn', 'trigger', '종가 EMA20 하향 이탈')
def _(d): return cross_dn(d.c, d.ema20)
@reg('t_low10', 'trigger', '종가 10일 최저 종가 하향 이탈')
def _(d): return d.c < d.low10
@reg('t_low20', 'trigger', '종가 20일 최저 종가 하향 이탈')
def _(d): return d.c < d.low20
@reg('t_dd15', 'trigger', '60일 고점 대비 -15% 도달')
def _(d): return d.dd60 <= -.15
@reg('t_ema_dead', 'trigger', 'EMA10<EMA20 데드크로스')
def _(d): return cross_dn(d.ema10, d.ema20)
@reg('t_rs_low20', 'trigger', '코인/BTC 20일 최저 경신')
def _(d): return d.rs < d.rs_low20 if 'rs' in d else pd.Series(False, index=d.index)

# ---- slow regime triggers (exit-only family)
@reg('x_ema50_dn', 'regime', '종가 EMA50 하향 이탈')
def _(d): return cross_dn(d.c, d.ema50)
@reg('x_ema100_dn', 'regime', '종가 EMA100 하향 이탈')
def _(d): return cross_dn(d.c, d.ema100)
@reg('x_ema200_dn', 'regime', '종가 EMA200 하향 이탈')
def _(d): return cross_dn(d.c, d.ema200)
@reg('x_dead2050', 'regime', 'EMA20<EMA50 데드크로스')
def _(d): return cross_dn(d.ema20, d.ema50)
@reg('x_dd25', 'regime', '60일 고점 대비 -25% 도달')
def _(d): return d.dd60 <= -.25

# ---- market context (levels)
@reg('m_btc_lt20', 'market', 'BTC < EMA20')
def _(d): return d.btc < d.btc_ema20 if 'btc' in d else pd.Series(False, index=d.index)
@reg('m_btc_lt50', 'market', 'BTC < EMA50')
def _(d): return d.btc < d.btc_ema50 if 'btc' in d else pd.Series(False, index=d.index)
@reg('m_btc_dd10', 'market', 'BTC 60일 고점 대비 -10% 이하')
def _(d): return d.btc_dd60 <= -.10 if 'btc' in d else pd.Series(False, index=d.index)
@reg('m_breadth60', 'market', '유니버스 60% 이상이 EMA20 아래')
def _(d): return d.breadth_below20 >= .6 if 'breadth_below20' in d else pd.Series(False, index=d.index)
@reg('m_rs_lt20', 'market', '코인/BTC < 자체 EMA20')
def _(d): return d.rs < d.rs_ema20 if 'rs' in d else pd.Series(False, index=d.index)

# ---- rebuy conditions
@reg('r_rsi_up30', 'rebuy', 'RSI 30 상향 돌파')
def _(d): return (d.rsi > 30) & (d.rsi.shift() <= 30)
@reg('r_oversold_recent', 'rebuy', 'RSI 30 이하 (최근 10일)')
def _(d): return recent(d.rsi <= 30, 10)
@reg('r_reclaim_ema20', 'rebuy', '종가 EMA20 상향 회복')
def _(d): return cross_up(d.c, d.ema20)
@reg('r_ema20_up', 'rebuy', 'EMA20 3일 전보다 상승')
def _(d): return d.ema20 > d.ema20.shift(3)
@reg('r_break_high20', 'rebuy', '20일 최고 종가 돌파')
def _(d): return d.c > d.high20
@reg('r_ema_golden', 'rebuy', 'EMA10>EMA20 골든크로스')
def _(d): return cross_up(d.ema10, d.ema20)
@reg('r_deep_dd30', 'rebuy', '60일 고점 대비 -30% 이하')
def _(d): return d.dd60 <= -.30
@reg('r_btc_gt20', 'rebuy', 'BTC > EMA20')
def _(d): return d.btc > d.btc_ema20 if 'btc' in d else pd.Series(False, index=d.index)
@reg('r_rs_gt20', 'rebuy', '코인/BTC > 자체 EMA20')
def _(d): return d.rs > d.rs_ema20 if 'rs' in d else pd.Series(False, index=d.index)
@reg('r_breadth_ok', 'rebuy', '유니버스 EMA20 아래 비중 50% 미만')
def _(d): return d.breadth_below20 < .5 if 'breadth_below20' in d else pd.Series(False, index=d.index)
@reg('r_vol_calm', 'rebuy', '변동성 하위 40%')
def _(d): return d.rv_pct <= .4
@reg('r_higher_low', 'rebuy', '10일 저점이 직전 10일 저점보다 높음')
def _(d): return d.hl10
@reg('r_macd_up', 'rebuy', 'MACD 히스토그램 양전환')
def _(d): return (d.macd_hist > 0) & (d.macd_hist.shift() <= 0)

def names(role):
    return [k for k, v in C.items() if v[0] == role]

def label(k):
    return C[k][1]

def conditions(df: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({k: v[2](df).fillna(False).astype(bool) for k, v in C.items()}, index=df.index)

def composite(cond: pd.DataFrame, parts: list[str]) -> pd.Series:
    out = pd.Series(True, index=cond.index)
    for p in parts: out &= cond[p]
    return out

def events(level: pd.Series, cooldown: int = 14) -> list:
    """rising edges of `level` with min `cooldown` days between accepted events."""
    idx = level.index[edge(level)]
    out, last = [], None
    for t in idx:
        if last is None or (t - last).days >= cooldown:
            out.append(t); last = t
    return out
