import json, os
import pandas as pd
from . import signals as S, products as P

_STATS = None
def stats():
    global _STATS
    if _STATS is None:
        p = os.path.join(os.path.dirname(__file__), '..', 'config', 'stats.json')
        _STATS = json.load(open(p, encoding='utf-8')) if os.path.exists(p) else {}
    return _STATS

def _px(x):
    if x is None: return 'n/a'
    return f'${x:,.2f}' if x >= 1 else f'${x:,.4f}' if x >= .01 else f'${x:,.6f}'
def _r(x):
    return 'n/a' if x is None else f'{x:.0f}'
def _pc(x, plus=True):
    if x is None: return 'n/a'
    return f'{x * 100:+.1f}%' if plus else f'{x * 100:.0f}%'

def snapshot(f, d):
    """indicator readings at close d vs 5 bars earlier; used both in text and in stored JSON."""
    i = f.index.get_loc(d); r = f.iloc[i]; p = f.iloc[max(i - 5, 0)]
    def g(row, k): return float(row[k]) if k in row and pd.notna(row[k]) else None
    s = dict(close=g(r, 'c'), rsi=g(r, 'rsi'), rsi_5d_ago=g(p, 'rsi'),
             vs_ema20=(r.c / r.ema20 - 1) if pd.notna(r.ema20) else None, vs_ema50=(r.c / r.ema50 - 1) if pd.notna(r.ema50) else None,
             dd60=g(r, 'dd60'), high20=g(r, 'high20'),
             btc_vs_ema20=(r.btc / r.btc_ema20 - 1) if 'btc' in r and pd.notna(r.btc_ema20) else None,
             btc_vs_ema50=(r.btc / r.btc_ema50 - 1) if 'btc' in r and pd.notna(r.btc_ema50) else None,
             rs_vs_ema20=(r.rs / r.rs_ema20 - 1) if 'rs' in r and pd.notna(r.rs_ema20) else None,
             breadth_below20=g(r, 'breadth_below20'), vol_pct=g(r, 'rv_pct'))
    return s

def _market_line(s):
    parts = []
    if s['btc_vs_ema20'] is not None: parts.append(f"BTC EMA20 대비 {_pc(s['btc_vs_ema20'])}·EMA50 대비 {_pc(s['btc_vs_ema50'])}")
    if s['rs_vs_ema20'] is not None: parts.append(f"코인/BTC EMA20 대비 {_pc(s['rs_vs_ema20'])}")
    if s['breadth_below20'] is not None: parts.append(f"알트 {_pc(s['breadth_below20'], False)}가 EMA20 아래")
    return ' · '.join(parts)

def _when(d):
    nxt = d + pd.Timedelta(days=1)
    return f"{d.date()} 일봉 마감(UTC) = 한국시간 {nxt.month}/{nxt.day} 09:00"

def build(prod, action, symbol, d, feats, cond, validated, late=False, extra=None):
    f = feats[symbol] if isinstance(feats, dict) else feats
    c = cond[symbol] if isinstance(cond, dict) else cond
    s = snapshot(f, d); st = stats(); extra = extra or {}
    tag = '' if validated else ' ⚠검증 대상 외 종목'
    late_tag = ' (지연 발송)' if late else ''
    L = [f"기준: {_when(d)} · 종가 {_px(s['close'])}"]
    if prod == 'B' and action == 'SELL':
        title = f"🔻 매도 신호 [{symbol}] · 매도·재진입형{tag}{late_tag}"
        ema20 = float(f.at[d, 'ema20'])
        L.append(f"▸ 종가 {_px(s['close'])}가 EMA20({_px(ema20)}) 아래로 이탈 ({_pc(s['vs_ema20'])})")
        L.append(f"▸ RSI14 {_r(s['rsi_5d_ago'])}→{_r(s['rsi'])}(5일) · EMA50 대비 {_pc(s['vs_ema50'])} · 60일 고점 대비 {_pc(s['dd60'])}")
        L.append('▸ ' + _market_line(s))
        L.append('▸ 다음: 재진입 알림(종가가 20일 최고 종가 돌파 + BTC>EMA20, 매도 후 2일 이상) 또는 60일 경과 시 발송. 그동안 현금 대기')
        if st.get('B'):
            v = st['B']['val']
            L.append(f"▸ 과거 검증 {st['B']['val_period']}({v['trips']}회): 재진입가가 매도가보다 낮았던 비율 {_pc(v['cheaper_pct'], False)}, 중앙값 {_pc(v['median_chg'])}(대체로 더 비싸게 재진입), 대기 중앙값 {v['median_days_out']:.0f}일")
            pl = st['B']['pooled']
            L.append(f"▸ 같은 기간 10종목 합산: 이 규칙 {pl['strategy_total'] * 100:+.0f}% vs 보유 {pl['hold_total'] * 100:+.0f}%, 최대낙폭 {pl['strategy_mdd'] * 100:.0f}% vs {pl['hold_mdd'] * 100:.0f}%")
        L.append('▸ 주의: 고점 매도 신호가 아니라 추세 이탈 신호. 체결이 하루만 늦어도 성과가 크게 줄어드는 것으로 확인됨(알림 즉시 대응 전제)')
        L.append(f"▸ 신뢰도: {st.get('B', {}).get('confidence', '')}")
        ind = ['t_ema20_dn']
    elif prod == 'B' and action == 'BUY':
        sig = extra.get('reason') == 'signal'
        title = f"🔼 재진입 신호 [{symbol}] · 매도·재진입형{tag}{late_tag}"
        if sig:
            L.append(f"▸ 종가 {_px(s['close'])}가 직전 20일 최고 종가({_px(s['high20'])})를 돌파 ({_pc(s['close'] / s['high20'] - 1 if s['high20'] else None)}) + BTC가 EMA20 위({_pc(s['btc_vs_ema20'])})")
        else:
            L.append(f"▸ 돌파 신호 없이 매도 후 {P.B_TIMEOUT_DAYS}일 경과로 시간 만료 재진입")
        sp = extra.get('sell_price')
        if sp:
            L.append(f"▸ 매도 알림({extra.get('sell_date')}) {_px(sp)} → 현재 {_px(s['close'])} ({_pc(s['close'] / sp - 1)}), 대기 {extra.get('out_days')}일")
        L.append(f"▸ RSI14 {_r(s['rsi_5d_ago'])}→{_r(s['rsi'])}(5일) · EMA20 대비 {_pc(s['vs_ema20'])} · 60일 고점 대비 {_pc(s['dd60'])}")
        L.append('▸ ' + _market_line(s))
        if st.get('B'): L.append(f"▸ 과거 검증상 재진입가가 매도가보다 낮은 경우는 {_pc(st['B']['val']['cheaper_pct'], False)}뿐이었음. 이 규칙의 성과는 '싸게 사기'가 아니라 '추세 구간에 머물기'에서 나옴")
        L.append(f"▸ 신뢰도: {st.get('B', {}).get('confidence', '')}")
        ind = ['r_break_high20', 'r_btc_gt20']
    else:  # A sell
        title = f"🚪 매도 경고 [{symbol}] · 매도전용형(참고용){tag}{late_tag}"
        fired = [S.label(t) for t in P.A_TRIGGERS if bool(S.recent(c[t], P.A_TRIGGER_WINDOW).at[d])]
        flags = [S.label(t) for t in P.A_FLAGS if bool(c.at[d, t])]
        L.append(f"▸ 중장기 추세 이탈(최근 {P.A_TRIGGER_WINDOW}일 내): " + ', '.join(fired))
        L.append(f"▸ 동시 확인된 시장 약세 {len(flags)}/{len(P.A_FLAGS)}: " + ', '.join(flags))
        L.append(f"▸ RSI14 {_r(s['rsi_5d_ago'])}→{_r(s['rsi'])}(5일) · EMA50 대비 {_pc(s['vs_ema50'])} · 60일 고점 대비 {_pc(s['dd60'])}")
        L.append('▸ ' + _market_line(s))
        if st.get('A'):
            v = st['A']['val']
            L.append(f"▸ 과거 검증(2023~26, {v['n']}건/{v['dates']}개 날짜): 신호 후 30일 평균 {_pc(v['r30'])} (무작위 시점 {_pc(v['plc_r30'])}), 90일 평균 {_pc(v['r90'])} (무작위 {_pc(v['plc_r90'])})")
            L.append(f"▸ 단, '-20% 먼저 도달' 비율은 {_pc(v['dn20'], False)}로 무작위 {_pc(v['plc_dn'], False)}와 구분 안 됨. 큰 폭락 예측 신호가 아님")
        L.append('▸ 재진입 알림은 없음(매도 전용). 재진입은 직접 판단하거나 매도·재진입형 알림을 참고')
        L.append(f"▸ 신뢰도: {st.get('A', {}).get('confidence', '')}")
        ind = P.A_TRIGGERS + P.A_FLAGS
    ind_json = dict(s, active=[k for k in ind if k in c.columns and bool(c.at[d, k])])
    return dict(candle_date=str(d.date()), symbol=symbol, category=prod, action=action, price=s['close'], title=title, body='\n'.join(L), indicators=ind_json, late=late)
