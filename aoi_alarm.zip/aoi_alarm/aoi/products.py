"""Frozen signal definitions. These constants are exactly what research/ validated. Change them only after re-validating."""
UNIVERSE = ['ETH', 'XRP', 'ADA', 'LINK', 'DOGE', 'SOL', 'AVAX', 'NEAR', 'SUI', 'ONDO']   # breadth universe + validated coins

# Product B: sell -> re-buy cycle ("매도·재진입형")
B_SELL = ['t_ema20_dn']
B_REBUY = ['r_break_high20', 'r_btc_gt20']
B_TIMEOUT_DAYS = 60
B_MIN_OUT_DAYS = 2

# Product A: sell-only regime exit ("매도전용형")
A_TRIGGERS = ['x_ema50_dn', 'x_ema100_dn', 'x_dead2050']
A_TRIGGER_WINDOW = 5
A_FLAGS = ['m_btc_lt50', 'm_btc_dd10', 'm_breadth60']
A_MIN_FLAGS = 2
A_COOLDOWN_DAYS = 14

MIN_HISTORY_BARS = 200   # no alerts until a coin has this many daily bars (indicator warm-up used in research)
