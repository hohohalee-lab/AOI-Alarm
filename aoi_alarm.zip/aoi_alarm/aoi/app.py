"""CLI:  python -m aoi.app run | replay | history | status | test-notify | viewer"""
import argparse, json, os, sys
import pandas as pd
from . import engine, notify, products as P
from .data_sources import CoinbaseSource, CsvSource, fx_krw
from .store import Store
from . import viewer, status as ST

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
def load_cfg(path=None):
    cfg = json.load(open(path or os.environ.get('AOI_CONFIG') or os.path.join(ROOT, 'config', 'watchlist.json'), encoding='utf-8'))
    # CI/phone setup keeps mutable state OUTSIDE the unzipped app folder (see ci/run.sh)
    if os.environ.get('AOI_STATE_DIR'): cfg['db_path'] = os.path.join(os.environ['AOI_STATE_DIR'], 'aoi.db')
    if os.environ.get('AOI_DOCS_DIR'): cfg['docs_dir'] = os.environ['AOI_DOCS_DIR']
    return cfg

def validated_set():
    from . import messages
    return set(messages.stats().get('universe_validated', P.UNIVERSE))

def state_rows(store, symbols):
    out = []
    for s in symbols:
        st = store.state(s)
        if st: out.append(dict(symbol=s, b_state=st['b_state'], b_sell_date=st['b_sell_date']))
    return out

def deliver(store, channels, alerts_cfg=None):
    n_ok = 0
    for a in store.pending():
        errs = []
        ok_any = False
        for ch in channels:
            try:
                ch.send(a['title'], a['body'], urgent=(a['category'] == 'B')); ok_any = True
            except Exception as e:
                errs.append(f'{ch.name}: {e}')
        store.mark_delivery(a['id'], ok_any, '; '.join(errs) or None); n_ok += ok_any
        if errs: print('[deliver] problems:', errs, file=sys.stderr)
    return n_ok

def process_all(cfg, closes, store, latest, symbols, only_after=None):
    feats, conds = engine.compute(closes, symbols)
    val = validated_set(); new = []
    for e in cfg['watchlist']:
        s = e['symbol']
        if store.state(s) is None:
            engine.init_state(store, dict(e), latest - pd.Timedelta(days=1))
        start_after = pd.Timestamp(only_after) if only_after else pd.Timestamp(store.state(s)['last_processed'])
        new += engine.process_symbol(s, feats[s], conds[s], store, start_after, latest, latest, s in val)
    process_all.last = (feats, conds, val)
    return new

def cmd_run(args):
    cfg = load_cfg(args.config); store = Store(os.path.join(ROOT, cfg.get('db_path', 'data/aoi.db')))
    src = CoinbaseSource(base_url=cfg.get('coinbase_base_url', 'https://api.exchange.coinbase.com'), pause=cfg.get('coinbase_pause', 0.35))
    symbols = [e['symbol'].upper() for e in cfg['watchlist']]
    for e in cfg['watchlist']: e['symbol'] = e['symbol'].upper()
    closes, skipped = {}, []
    for s in sorted(set(['BTC'] + P.UNIVERSE + symbols)):
        try: closes[s] = src.closes(s, 450)
        except Exception as ex:
            if s in ('BTC',) or s in P.UNIVERSE and s not in symbols: raise
            skipped.append(s); print(f'[skip] {s}: {ex}', file=sys.stderr)
    cfg['watchlist'] = [e for e in cfg['watchlist'] if e['symbol'] in closes]
    symbols = [e['symbol'] for e in cfg['watchlist']]
    latest = min(closes['BTC'].index.max(), *[closes[s].index.max() for s in symbols])
    new = process_all(cfg, closes, store, latest, symbols)
    chans = notify.build(cfg.get('notify', {}))
    n = deliver(store, chans)
    store.log_run(str(latest.date()), f'new={len(new)} delivered={n}')
    feats, conds, val = process_all.last
    status_list = [ST.build(e['symbol'], feats[e['symbol']], conds[e['symbol']], store.state(e['symbol']), e['symbol'] in val, latest) for e in cfg['watchlist']]
    fx, fx_src = fx_krw(cfg.get('fx_fallback_krw'))
    pos_by = {e['symbol']: e for e in cfg['watchlist']}
    for st in status_list:
        e = pos_by[st['symbol']]
        if fx and e.get('qty') and e.get('avg_buy_krw') and st.get('close'):
            avg = e['avg_buy_krw'] / fx; cost = e['qty'] * avg; val = e['qty'] * st['close']
            st['position'] = dict(qty=e['qty'], avg_usd=avg, cost_usd=cost, value_usd=val, pnl_usd=val - cost, ret=val / cost - 1, avg_krw=e['avg_buy_krw'])
    docs = os.path.join(ROOT, cfg.get('docs_dir', 'docs'))
    viewer.export(store, docs, status_list, skipped=skipped, fx=dict(krw=fx, source=fx_src))
    print(f'latest closed candle {latest.date()} (UTC) | new alerts {len(new)} | delivered {n} | app data -> {docs}/data')

def cmd_replay(args):
    """Replay history from a CSV (no network, console output) to see what the alarms would have said."""
    cfg = load_cfg(args.config); import tempfile
    store = Store(os.path.join(tempfile.mkdtemp(), 'replay.db'))
    src = CsvSource(args.csv, until=args.to)
    syms = [s.upper() for s in args.symbols] if args.symbols else [e['symbol'].upper() for e in cfg['watchlist']]
    cfg['watchlist'] = [dict(symbol=s, holding=True) for s in syms]
    closes = {s: src.closes(s, 100000) for s in sorted(set(['BTC'] + P.UNIVERSE + syms))}
    latest = closes['BTC'].index.max()
    # initialise state at the day before --from, then walk forward
    start = pd.Timestamp(args.from_) - pd.Timedelta(days=1)
    for e in cfg['watchlist']: engine.init_state(store, e, start)
    new = process_all(cfg, closes, store, latest, syms, only_after=start)
    chans = [notify.Console()] if args.print else []
    for a in new:
        for ch in chans: ch.send(a['title'], a['body'])
    print(f'replay {args.from_}..{latest.date()} symbols={syms}: {len(new)} alerts')
    return new

def cmd_history(args):
    cfg = load_cfg(args.config); store = Store(os.path.join(ROOT, cfg.get('db_path', 'data/aoi.db')))
    for a in store.history(args.n): print(f"{a['candle_date']}  {a['symbol']:6s} {a['category']}/{a['action']:4s} {a['price']:<12.6g} {a['title']}")

def cmd_status(args):
    cfg = load_cfg(args.config); store = Store(os.path.join(ROOT, cfg.get('db_path', 'data/aoi.db')))
    for e in cfg['watchlist']: print(e['symbol'], store.state(e['symbol'].upper()))

def cmd_test_notify(args):
    cfg = load_cfg(args.config)
    for ch in notify.build(cfg.get('notify', {})):
        ch.send('AOI 알람 테스트', '이 메시지가 폰에 팝업으로 보이면 설정 완료입니다.', urgent=True); print('sent via', ch.name)

def cmd_viewer(args):
    print('The phone app reads docs/data/*.json, written by `run`. Nothing else to do.')

def main(argv=None):
    ap = argparse.ArgumentParser(prog='aoi'); ap.add_argument('--config'); sp = ap.add_subparsers(dest='cmd', required=True)
    sp.add_parser('run').set_defaults(f=cmd_run)
    r = sp.add_parser('replay'); r.add_argument('--csv', default=os.path.join(ROOT, 'data', 'closes.csv')); r.add_argument('--from', dest='from_', required=True)
    r.add_argument('--to'); r.add_argument('--symbols', nargs='*'); r.add_argument('--print', action='store_true'); r.set_defaults(f=cmd_replay)
    h = sp.add_parser('history'); h.add_argument('-n', type=int, default=30); h.set_defaults(f=cmd_history)
    sp.add_parser('status').set_defaults(f=cmd_status); sp.add_parser('test-notify').set_defaults(f=cmd_test_notify); sp.add_parser('viewer').set_defaults(f=cmd_viewer)
    a = ap.parse_args(argv); a.f(a)

if __name__ == '__main__':
    main()
