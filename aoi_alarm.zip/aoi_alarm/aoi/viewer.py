import json, html
from datetime import datetime, timezone

TEMPLATE = """<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>AOI 알람 이력</title><style>
:root{--bg:#f6f7f9;--card:#fff;--tx:#14181f;--mut:#667085;--bd:#e4e7ec;--sell:#c2410c;--buy:#0f766e;--ref:#6d28d9}
@media(prefers-color-scheme:dark){:root{--bg:#0f1218;--card:#181c25;--tx:#e8ebf0;--mut:#98a2b3;--bd:#2a303c;--sell:#fb923c;--buy:#2dd4bf;--ref:#a78bfa}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.55 -apple-system,"Apple SD Gothic Neo","Noto Sans KR",system-ui,sans-serif}
main{max-width:760px;margin:0 auto;padding:16px}h1{font-size:19px;margin:6px 0 2px}.sub{color:var(--mut);font-size:13px;margin-bottom:12px}
.row{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.chip{border:1px solid var(--bd);background:var(--card);color:var(--tx);border-radius:999px;padding:6px 12px;font-size:13px;cursor:pointer}
.chip.on{background:var(--tx);color:var(--bg)}.card{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:12px 14px;margin:10px 0}
.hd{display:flex;justify-content:space-between;gap:8px;align-items:baseline}.t{font-weight:650}.sell{color:var(--sell)}.buy{color:var(--buy)}.ref{color:var(--ref)}
.d{color:var(--mut);font-size:12px;white-space:nowrap}pre{white-space:pre-wrap;word-break:keep-all;overflow-wrap:anywhere;font-family:inherit;font-size:13px;line-height:1.6;margin:8px 0 0;color:var(--tx)}
.st{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}.st div{border:1px solid var(--bd);background:var(--card);border-radius:10px;padding:8px 10px;font-size:13px}
.empty{color:var(--mut);padding:24px 0;text-align:center}</style></head><body><main>
<h1>AOI 알람 이력</h1><div class="sub" id="sub"></div>
<div class="st" id="st"></div>
<div class="row" id="f1"></div><div class="row" id="f2"></div><div id="list"></div>
</main><script>
const DATA=__DATA__;let fs='ALL',fc='ALL';
const CAT={B:'매도·재진입형',A:'매도전용형(참고)'};
document.getElementById('sub').textContent='갱신 '+DATA.generated+' · 총 '+DATA.alerts.length+'건 · 종가 기준 일봉(UTC), 한국시간 09:00 마감';
document.getElementById('st').innerHTML=DATA.state.map(s=>'<div><b>'+s.symbol+'</b><br>'+(s.b_state==='IN'?'보유(IN)':'현금 대기(OUT) '+(s.b_sell_date||''))+'</div>').join('');
function chips(id,vals,cur,set){const el=document.getElementById(id);el.innerHTML='';vals.forEach(v=>{const b=document.createElement('button');b.className='chip'+(v[0]===cur?' on':'');b.textContent=v[1];b.onclick=()=>{set(v[0]);draw()};el.appendChild(b)})}
function draw(){chips('f1',[['ALL','전체 종목']].concat([...new Set(DATA.alerts.map(a=>a.symbol))].map(s=>[s,s])),fs,v=>fs=v);
chips('f2',[['ALL','전체 분류'],['B','매도·재진입형'],['A','매도전용형']],fc,v=>fc=v);
const L=DATA.alerts.filter(a=>(fs==='ALL'||a.symbol===fs)&&(fc==='ALL'||a.category===fc));
document.getElementById('list').innerHTML=L.length?L.map(a=>{const cl=a.action==='BUY'?'buy':(a.category==='A'?'ref':'sell');
return '<div class="card"><div class="hd"><span class="t '+cl+'">'+esc(a.title)+'</span><span class="d">'+a.candle_date+'</span></div><pre>'+esc(a.body)+'</pre></div>'}).join(''):'<div class="empty">아직 알람이 없습니다</div>'}
function esc(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
draw();</script></body></html>"""

def generate(store, path, state_rows):
    alerts = store.history(1000)
    data = dict(generated=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'), alerts=[{k: a[k] for k in ('candle_date', 'symbol', 'category', 'action', 'title', 'body', 'price', 'late')} for a in alerts], state=state_rows)
    blob = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
    open(path, 'w', encoding='utf-8').write(TEMPLATE.replace('__DATA__', blob))
    return path


def export(store, docs_dir, status_list, generated=None, skipped=None, fx=None):
    """JSON consumed by the phone app (docs/index.html). Replaces the old single-file viewer."""
    import os
    os.makedirs(os.path.join(docs_dir, 'data'), exist_ok=True)
    gen = generated or datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    hist = [{k: a[k] for k in ('candle_date', 'symbol', 'category', 'action', 'title', 'body', 'price', 'late', 'created_utc')} for a in store.history(1000)]
    json.dump(dict(generated=gen, alerts=hist), open(os.path.join(docs_dir, 'data', 'history.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    json.dump(dict(generated=gen, symbols=status_list, skipped=skipped or [], fx=fx), open(os.path.join(docs_dir, 'data', 'status.json'), 'w', encoding='utf-8'), ensure_ascii=False)
