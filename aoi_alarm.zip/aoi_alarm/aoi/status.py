"""Per-symbol live status for the phone app (docs/data/status.json): state, indicator readings, distance to next alarm."""
import pandas as pd
from . import messages as M, signals as S, products as P

def build(symbol, feats, cond, st, validated, latest):
    f, c = feats, cond
    d = latest if latest in f.index else f.index[-1]
    s = M.snapshot(f, d); close = s['close']
    out = dict(symbol=symbol, validated=bool(validated), asof=str(d.date()), close=close, state=st['b_state'], sell_date=st['b_sell_date'],
               sell_price=st['b_sell_price'], indicators=s)
    ema20 = float(f.at[d, 'ema20']) if pd.notna(f.at[d, 'ema20']) else None
    high20 = float(f.at[d, 'high20']) if pd.notna(f.at[d, 'high20']) else None
    if st['b_state'] == 'IN':
        out['next'] = dict(kind='SELL', title='다음: 매도 알람 조건', items=[
            dict(label=f"종가가 EMA20({M._px(ema20)}) 아래로 이탈", ok=False, gap=(close / ema20 - 1) if ema20 else None, note='현재 EMA20 위' if ema20 and close > ema20 else '이미 아래(다음 이탈 신호는 재상승 후)')])
    else:
        od = (d - pd.Timestamp(st['b_sell_date'])).days if st['b_sell_date'] else None
        out['out_days'] = od
        out['next'] = dict(kind='BUY', title='다음: 재진입 알람 조건 (모두 충족 시)', items=[
            dict(label=f"종가가 20일 최고 종가({M._px(high20)}) 돌파", ok=bool(high20 and close > high20), gap=(close / high20 - 1) if high20 else None),
            dict(label='BTC > EMA20', ok=bool(c.at[d, 'r_btc_gt20'])),
            dict(label=f'매도 후 {P.B_MIN_OUT_DAYS}일 이상 (현재 {od}일)', ok=bool(od is not None and od >= P.B_MIN_OUT_DAYS))],
            timeout=dict(days=P.B_TIMEOUT_DAYS, left=max(0, P.B_TIMEOUT_DAYS - (od or 0))))
    out['A'] = dict(needed=P.A_MIN_FLAGS,
                    triggers=[dict(label=S.label(t), on=bool(S.recent(c[t], P.A_TRIGGER_WINDOW).at[d])) for t in P.A_TRIGGERS],
                    flags=[dict(label=S.label(t), on=bool(c.at[d, t])) for t in P.A_FLAGS])
    out['A']['count'] = sum(x['on'] for x in out['A']['flags'])
    return out
