import json, sqlite3, os
from datetime import datetime, timezone

SCHEMA = """
CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT, created_utc TEXT, candle_date TEXT, symbol TEXT, category TEXT, action TEXT,
  price REAL, title TEXT, body TEXT, indicators TEXT, late INTEGER DEFAULT 0, delivered INTEGER DEFAULT 0, delivery_error TEXT,
  UNIQUE(symbol, category, action, candle_date));
CREATE TABLE IF NOT EXISTS state(
  symbol TEXT PRIMARY KEY, b_state TEXT, b_sell_date TEXT, b_sell_price REAL, last_a_date TEXT, last_processed TEXT);
CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts_utc TEXT, latest_candle TEXT, note TEXT);
"""

class Store:
    def __init__(self, path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.db = sqlite3.connect(path); self.db.row_factory = sqlite3.Row; self.db.executescript(SCHEMA); self.db.commit()

    def state(self, symbol):
        r = self.db.execute('SELECT * FROM state WHERE symbol=?', (symbol,)).fetchone()
        return dict(r) if r else None

    def save_state(self, symbol, **kw):
        cur = self.state(symbol) or dict(symbol=symbol, b_state='IN', b_sell_date=None, b_sell_price=None, last_a_date=None, last_processed=None)
        cur.update(kw)
        self.db.execute('INSERT OR REPLACE INTO state(symbol,b_state,b_sell_date,b_sell_price,last_a_date,last_processed) VALUES(?,?,?,?,?,?)',
                        (cur['symbol'], cur['b_state'], cur['b_sell_date'], cur['b_sell_price'], cur['last_a_date'], cur['last_processed']))
        self.db.commit()

    def add_alert(self, a: dict):
        """returns alert id, or None if this (symbol, category, action, candle) already exists (idempotent re-runs)."""
        try:
            cur = self.db.execute('INSERT INTO alerts(created_utc,candle_date,symbol,category,action,price,title,body,indicators,late) VALUES(?,?,?,?,?,?,?,?,?,?)',
                                  (datetime.now(timezone.utc).isoformat(timespec='seconds'), a['candle_date'], a['symbol'], a['category'], a['action'], a['price'],
                                   a['title'], a['body'], json.dumps(a['indicators'], ensure_ascii=False), int(a.get('late', False))))
            self.db.commit(); return cur.lastrowid
        except sqlite3.IntegrityError:
            return None

    def mark_delivery(self, alert_id, ok, err=None):
        self.db.execute('UPDATE alerts SET delivered=?, delivery_error=? WHERE id=?', (int(ok), err, alert_id)); self.db.commit()

    def pending(self):
        return [dict(r) for r in self.db.execute('SELECT * FROM alerts WHERE delivered=0 ORDER BY id')]

    def history(self, limit=500):
        return [dict(r) for r in self.db.execute('SELECT * FROM alerts ORDER BY candle_date DESC, id DESC LIMIT ?', (limit,))]

    def log_run(self, latest, note=''):
        self.db.execute('INSERT INTO runs(ts_utc,latest_candle,note) VALUES(?,?,?)', (datetime.now(timezone.utc).isoformat(timespec='seconds'), latest, note)); self.db.commit()
