"""Close-based daily features. Every value at row t uses data up to and including close t only."""
import numpy as np
import pandas as pd

def rma(x, n):
    return x.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()

def rsi(c, n=14):
    d = c.diff()
    g, l = rma(d.clip(lower=0), n), rma(-d.clip(upper=0), n)
    out = 100 * g / (g + l)
    return out.where((g + l) > 0, 50).where(g.notna())

def ema(c, n):
    return c.ewm(span=n, adjust=False, min_periods=n).mean()

def pct_rank(s, n=365, minp=180):
    return s.rolling(n, min_periods=minp).rank(pct=True)

def coin_features(c: pd.Series, btc: pd.Series | None, breadth_below20: pd.Series | None) -> pd.DataFrame:
    df = pd.DataFrame({'c': c})
    r = c.pct_change()
    df['rsi'] = rsi(c)
    for n in (10, 20, 50, 100, 200):
        df[f'ema{n}'] = ema(c, n)
    sma20 = c.rolling(20).mean(); sd20 = c.rolling(20).std()
    df['sma20'] = sma20; df['bb_up'] = sma20 + 2 * sd20; df['bb_lo'] = sma20 - 2 * sd20
    df['dist20'] = c / sma20 - 1
    macd = ema(c, 12) - ema(c, 26)
    df['macd_hist'] = macd - macd.ewm(span=9, adjust=False, min_periods=9).mean()
    df['roc30'] = c / c.shift(30) - 1
    df['roc30_pct'] = pct_rank(df['roc30'])
    df['rv20'] = r.rolling(20).std() * np.sqrt(365)
    df['rv_pct'] = pct_rank(df['rv20'])
    df['hh60'] = c.rolling(60, min_periods=60).max()
    df['dd60'] = c / df['hh60'] - 1
    df['low10'] = c.shift().rolling(10).min(); df['low20'] = c.shift().rolling(20).min()
    df['high20'] = c.shift().rolling(20).max()
    df['hl10'] = c.rolling(10).min() > c.shift(10).rolling(10).min()   # higher low (closes)
    if btc is not None:
        b = btc.reindex(c.index)
        df['btc'] = b
        df['btc_ema20'] = ema(b, 20); df['btc_ema50'] = ema(b, 50)
        df['btc_dd60'] = b / b.rolling(60, min_periods=60).max() - 1
        df['btc_rsi'] = rsi(b)
        rs = c / b
        df['rs'] = rs; df['rs_ema20'] = ema(rs, 20); df['rs_low20'] = rs.shift().rolling(20).min()
    if breadth_below20 is not None:
        df['breadth_below20'] = breadth_below20.reindex(c.index)
    return df

def breadth_below_ema20(closes: pd.DataFrame, min_coins: int = 4) -> pd.Series:
    """Share of coins (in the supplied universe, excluding none) whose close < own EMA20. NaN if < min_coins valid."""
    below = pd.DataFrame({k: (v < ema(v.dropna(), 20).reindex(v.index)) for k, v in closes.items()})
    valid = pd.DataFrame({k: ema(v.dropna(), 20).reindex(v.index).notna() & v.notna() for k, v in closes.items()})
    share = (below & valid).sum(axis=1) / valid.sum(axis=1).replace(0, np.nan)
    return share.where(valid.sum(axis=1) >= min_coins)
