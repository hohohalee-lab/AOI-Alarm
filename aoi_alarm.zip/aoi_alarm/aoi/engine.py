import pandas as pd
from . import indicators as I, signals as S, products as P, messages as M

def compute(closes: dict, symbols: list):
    """closes: {symbol: Series of CLOSED daily closes, UTC date index}; must include 'BTC'. Returns feats, conds per symbol."""
    frame = pd.DataFrame(closes).sort_index()
    uni = [u for u in P.UNIVERSE if u in frame.columns]
    br = I.breadth_below_ema20(frame[uni]) if len(uni) >= 4 else None
    feats, conds = {}, {}
    for k in symbols:
        f = I.coin_features(frame[k].dropna(), frame['BTC'], br)
        feats[k] = f; conds[k] = S.conditions(f)
    return feats, conds

def a_level(cond: pd.DataFrame) -> pd.Series:
    trig = pd.concat([S.recent(cond[t], P.A_TRIGGER_WINDOW) for t in P.A_TRIGGERS], axis=1).any(axis=1)
    return trig & (cond[P.A_FLAGS].sum(axis=1) >= P.A_MIN_FLAGS)

def init_state(store, entry: dict, last_date):
    """first time a symbol is seen: holding -> IN, else OUT since `sold_on` (default: last closed candle)."""
    holding = entry.get('holding', True)
    if holding:
        store.save_state(entry['symbol'], b_state='IN', last_processed=str(last_date.date()) if last_date is not None else None)
    else:
        sold = entry.get('sold_on') or str(last_date.date())
        store.save_state(entry['symbol'], b_state='OUT', b_sell_date=sold, b_sell_price=entry.get('sold_price'), last_processed=str(last_date.date()))

def process_symbol(symbol, feats, cond, store, start_after, until, latest, validated, portfolio=None, sell_pct=None):
    """Walk candles in (start_after, until] in order; returns list of alert dicts (already stored)."""
    out = []
    st = store.state(symbol)
    a_lv = a_level(cond); a_edge = S.edge(a_lv)
    b_rebuy = S.composite(cond, P.B_REBUY)
    first_ok = feats.index[P.MIN_HISTORY_BARS] if len(feats) > P.MIN_HISTORY_BARS else None   # same 200-bar warm-up as research
    days = [d for d in feats.index if start_after < d <= until and first_ok is not None and d >= first_ok]
    for d in days:
        late = d < latest
        px = float(feats.at[d, 'c'])
        # ---- Product B state machine (identical to aoi.cycle.simulate)
        if st['b_state'] == 'IN':
            if bool(cond.at[d, P.B_SELL[0]]):
                al = M.build('B', 'SELL', symbol, d, feats, cond, validated, late, portfolio=portfolio, sell_pct=sell_pct)
                st['b_state'], st['b_sell_date'], st['b_sell_price'] = 'OUT', str(d.date()), px
                if store.add_alert(al): out.append(al)
        else:
            out_days = (d - pd.Timestamp(st['b_sell_date'])).days
            if out_days >= P.B_MIN_OUT_DAYS and (bool(b_rebuy.at[d]) or out_days >= P.B_TIMEOUT_DAYS):
                reason = 'signal' if bool(b_rebuy.at[d]) else 'timeout'
                al = M.build('B', 'BUY', symbol, d, feats, cond, validated, late, extra=dict(out_days=out_days, reason=reason, sell_price=st['b_sell_price'], sell_date=st['b_sell_date']))
                st['b_state'] = 'IN'
                if store.add_alert(al): out.append(al)
        # ---- Product A (sell-only): rising edge + cooldown
        if bool(a_edge.at[d]):
            last = st['last_a_date']
            if last is None or (d - pd.Timestamp(last)).days >= P.A_COOLDOWN_DAYS:
                al = M.build('A', 'SELL', symbol, d, feats, cond, validated, late, portfolio=portfolio)
                st['last_a_date'] = str(d.date())
                if store.add_alert(al): out.append(al)
        st['last_processed'] = str(d.date())
        store.save_state(symbol, **{k: v for k, v in st.items() if k != 'symbol'})
    return out
