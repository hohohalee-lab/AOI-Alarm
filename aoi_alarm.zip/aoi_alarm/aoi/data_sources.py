"""Daily close sources. Only CLOSED UTC daily bars are returned (the current, still-forming bar is dropped)."""
import json, time, urllib.request, urllib.error
from datetime import datetime, timezone, timedelta
import pandas as pd

class CoinbaseSource:
    """Public Coinbase Exchange candles: GET /products/{SYM}-USD/candles?granularity=86400 (max 300 bars per call)."""
    def __init__(self, base_url='https://api.exchange.coinbase.com', quote='USD', timeout=20, pause=0.35):
        self.base, self.quote, self.timeout, self.pause = base_url.rstrip('/'), quote, timeout, pause

    def _get(self, url):
        last = None
        for attempt in range(4):
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'aoi-alarm/1.0', 'Accept': 'application/json'})
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    return json.loads(r.read().decode())
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
                last = e; time.sleep(1.5 * (attempt + 1))
        raise RuntimeError(f'fetch failed: {url}: {last}')

    def closes(self, symbol: str, days: int = 450) -> pd.Series:
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        end = today; rows = []
        while days > 0:
            n = min(300, days); start = end - timedelta(days=n)
            q = f'start={start.strftime("%Y-%m-%dT%H:%M:%SZ")}&end={end.strftime("%Y-%m-%dT%H:%M:%SZ")}&granularity=86400'
            data = self._get(f'{self.base}/products/{symbol}-{self.quote}/candles?{q}')
            rows += data; end = start; days -= n; time.sleep(self.pause)
        if not rows: raise RuntimeError(f'no candles for {symbol}')
        df = pd.DataFrame(rows, columns=['t', 'low', 'high', 'open', 'close', 'volume']).drop_duplicates('t')
        s = pd.Series(df['close'].astype(float).values, index=pd.to_datetime(df['t'], unit='s')).sort_index()
        s = s[s.index < pd.Timestamp(today.replace(tzinfo=None))]              # drop forming bar
        return s.asfreq('D').ffill(limit=3).dropna()

class CsvSource:
    """For replay/tests: a wide CSV (date index, one close column per symbol)."""
    def __init__(self, path, until=None):
        self.df = pd.read_csv(path, index_col=0, parse_dates=True)
        if until: self.df = self.df.loc[:until]
    def closes(self, symbol, days=450):
        return self.df[symbol].dropna().iloc[-days:]


def fx_krw(fallback=None):
    """USD->KRW. Tries two free no-key APIs; returns (rate, source). source='fallback' if both fail."""
    for url, pick in (('https://open.er-api.com/v6/latest/USD', lambda d: d['rates']['KRW']),
                      ('https://api.frankfurter.app/latest?from=USD&to=KRW', lambda d: d['rates']['KRW'])):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'aoi-alarm/1.0'})
            with urllib.request.urlopen(req, timeout=15) as r:
                v = float(pick(json.loads(r.read().decode())))
            if 500 < v < 5000: return v, 'live'
        except Exception:
            pass
    return (float(fallback), 'fallback') if fallback else (None, 'none')
