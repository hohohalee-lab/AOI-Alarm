import json, os, urllib.request, urllib.parse, urllib.error

class Console:
    name = 'console'
    def send(self, title, body, urgent=False):
        print(f'\n=== {title} ===\n{body}\n'); return True

class Collector:
    """tests"""
    name = 'collector'
    def __init__(self): self.items = []
    def send(self, title, body, urgent=False): self.items.append((title, body)); return True

class Telegram:
    """Phone popup via Telegram bot. Needs env TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID."""
    name = 'telegram'
    def __init__(self, token=None, chat_id=None, api=None):
        api = api or os.environ.get('TELEGRAM_API_BASE') or 'https://api.telegram.org'
        self.token = token or os.environ.get('TELEGRAM_BOT_TOKEN'); self.chat = chat_id or os.environ.get('TELEGRAM_CHAT_ID'); self.api = api.rstrip('/')
        if not self.token or not self.chat: raise RuntimeError('TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID not set')
    def send(self, title, body, urgent=False):
        text = f'<b>{_esc(title)}</b>\n{_esc(body)}'
        data = urllib.parse.urlencode({'chat_id': self.chat, 'text': text[:4000], 'parse_mode': 'HTML', 'disable_web_page_preview': 'true',
                                       'disable_notification': 'false'}).encode()
        with urllib.request.urlopen(urllib.request.Request(f'{self.api}/bot{self.token}/sendMessage', data=data), timeout=20) as r:
            ok = json.loads(r.read().decode()).get('ok'); 
        if not ok: raise RuntimeError('telegram not ok')
        return True

class Ntfy:
    """Phone popup via ntfy (https://ntfy.sh app). Needs env NTFY_TOPIC (use a long random topic name)."""
    name = 'ntfy'
    def __init__(self, topic=None, server=None):
        self.topic = topic or os.environ.get('NTFY_TOPIC'); self.server = (server or os.environ.get('NTFY_SERVER') or 'https://ntfy.sh').rstrip('/')
        if not self.topic: raise RuntimeError('NTFY_TOPIC not set')
    def send(self, title, body, urgent=False):
        h = {'Title': _hdr(title), 'Priority': '5' if urgent else '4', 'Tags': 'bell'}
        req = urllib.request.Request(f'{self.server}/{self.topic}', data=body.encode('utf-8'), headers=h, method='POST')
        with urllib.request.urlopen(req, timeout=20) as r: r.read()
        return True

def _esc(s): return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
def _hdr(s):
    # HTTP headers are latin-1; ntfy accepts RFC2047 encoded words for UTF-8 titles
    import base64
    return '=?UTF-8?B?' + base64.b64encode(s.encode('utf-8')).decode() + '?='

def build(cfg_notify):
    chans = []
    for n in cfg_notify.get('channels', ['console']):
        try:
            chans.append({'telegram': Telegram, 'ntfy': Ntfy, 'console': Console}[n]())
        except RuntimeError as e:
            print(f'[notify] {n} disabled: {e}')
    return chans or [Console()]
