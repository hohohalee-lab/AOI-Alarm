"""Sell -> re-buy state machine on daily closes. Decisions at close t, filled at close t (24/7 market: next open ~= close)."""
import numpy as np
import pandas as pd
from . import signals as S

COST = 0.002   # 0.1% fee + 0.1% slippage per side

def simulate(c: pd.Series, sell_level: pd.Series, rebuy_level: pd.Series | None, start, end,
             timeout: int | None = None, min_out: int = 2, start_in: bool = True, cost: float = COST, lag: int = 0):
    """Returns DataFrame[pos, ret] over [start,end]. pos_t = position after the decision at close t."""
    c = c.loc[start:end]
    sl = S.edge(sell_level.reindex(c.index).fillna(False)).values
    rb = None if rebuy_level is None else rebuy_level.reindex(c.index).fillna(False).values
    n = len(c); pos = np.zeros(n); cur = 1.0 if start_in else 0.0; out_days = 0
    for i in range(n):
        if cur == 1.0:
            if sl[i] and i > 0:
                cur = 0.0; out_days = 0
        else:
            out_days += 1
            if rb is not None and out_days >= min_out and (rb[i] or (timeout is not None and out_days >= timeout)):
                cur = 1.0
        pos[i] = cur
    r = c.pct_change().fillna(0.0).values
    pe = np.r_[np.full(lag, 1.0 if start_in else 0.0), pos][:n]   # position actually held after `lag` extra days of execution delay
    gross = np.r_[0.0, pe[:-1] * r[1:]]
    switch = np.abs(np.diff(np.r_[1.0 if start_in else 0.0, pe]))
    net = gross - cost * switch
    return pd.DataFrame({'pos': pos, 'ret': net, 'hold': r}, index=c.index)

def metrics(ret: np.ndarray):
    eq = np.cumprod(1 + ret); peak = np.maximum.accumulate(np.r_[1.0, eq])[1:]
    return dict(total=eq[-1] - 1, mdd=(eq / peak - 1).min())
