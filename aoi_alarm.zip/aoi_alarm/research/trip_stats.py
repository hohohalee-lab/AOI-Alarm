from cyclelib import *
CFG = dict(sell=['t_ema20_dn'], rebuy=['r_break_high20','r_btc_gt20'], timeout=60)
def trips(k, start, end, cost=CY.COST):
    c = feats[k]['c']; sims = CY.simulate(c, S.composite(conds[k], CFG['sell']), S.composite(conds[k], CFG['rebuy']), max(start, c.index[0] + pd.Timedelta(days=200)), end, timeout=60)
    pos = sims['pos'].values; idx = sims.index; px = c.reindex(idx).values; out = []; i = 1
    while i < len(pos):
        if pos[i-1] == 1 and pos[i] == 0:
            j = i + 1
            while j < len(pos) and pos[j] == 0: j += 1
            if j < len(pos):
                days = j - i; sell_px, buy_px = px[i], px[j]
                kind = 'timeout' if days >= 60 else 'signal'
                out.append(dict(coin=k, sell=idx[i], buy=idx[j], days=days, chg=buy_px / sell_px - 1, kind=kind,
                                after30=px[min(i + 30, len(px) - 1)] / sell_px - 1, maxfall=px[i:j + 1].min() / sell_px - 1, maxrise=px[i:j + 1].max() / sell_px - 1))
            i = j
        else: i += 1
    return out
def summarize_trips(T, label):
    d = pd.DataFrame(T)
    net = d.chg - 2 * CY.COST   # round-trip cost
    print(f'{label}: round trips {len(d)} over {d.coin.nunique()} coins, {d.sell.dt.to_period("M").nunique()} distinct months')
    print(f'  rebuy price vs sell price: median {d.chg.median():+.1%}  mean {d.chg.mean():+.1%} | cheaper after costs in {(net < 0).mean():.0%} of trips | cheaper by >10% in {(d.chg < -.10).mean():.0%} | >10% HIGHER in {(d.chg > .10).mean():.0%}')
    print(f'  days out: median {d.days.median():.0f}, p25 {d.days.quantile(.25):.0f}, p75 {d.days.quantile(.75):.0f}; rebuy by 60d timeout: {(d.kind == "timeout").mean():.0%}')
    print(f'  price 30d after the sell alarm vs alarm price: below in {(d.after30 < 0).mean():.0%} of trips (median {d.after30.median():+.1%})')
    print(f'  while out: worst drop median {d.maxfall.median():+.1%}; best rise median {d.maxrise.median():+.1%}')
    return d
a, b = map(pd.Timestamp, VAL); da, db = map(pd.Timestamp, DEV)
Tv = []; Td = []
for k in ALTS_ALL: Tv += trips(k, a, b)
for k in ALTS_LONG: Td += trips(k, da, db)
dv = summarize_trips(Tv, 'VALIDATION 2023-2026 (10 alts)'); dd = summarize_trips(Td, 'DEV 2018-2022 (5 alts)')
dv.to_csv('../results/val_round_trips.csv', index=False); dd.to_csv('../results/dev_round_trips.csv', index=False)
# per-coin validation table
rows = []
for k in ALTS_ALL:
    c = feats[k]['c']; s0 = max(a, c.index[0] + pd.Timedelta(days=200))
    sm = CY.simulate(c, S.composite(conds[k], CFG['sell']), S.composite(conds[k], CFG['rebuy']), s0, b, timeout=60)
    m, h = CY.metrics(sm.ret.values), CY.metrics(sm.hold.values)
    rows.append(dict(coin=k, from_=str(s0.date()), strat=m['total'], hold=h['total'], strat_mdd=m['mdd'], hold_mdd=h['mdd'], in_market=sm.pos.mean(), round_trips=int((np.diff(sm.pos.values) == -1).sum())))
P = pd.DataFrame(rows); P.to_csv('../results/val_by_coin_B.csv', index=False); print(P.round(2).to_string(index=False))
