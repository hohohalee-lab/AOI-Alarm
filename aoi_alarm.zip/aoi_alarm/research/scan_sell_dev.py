import itertools, json, time
from events import *
cl = load('../data/closes.csv'); feats, conds = build_all(cl)
st = Study(cl, feats, conds, ALTS_LONG)          # discovery: 5 long-history alts only
DEV_EV = ('2018-07-01', '2022-10-01')
setups, trig, reg_, mkt = S.names('setup'), S.names('trigger'), S.names('regime'), S.names('market')
cands = [[x] for x in setups + trig + reg_ + mkt]
cands += [[s, t] for s in setups for t in trig]
cands += [[t, m] for t in trig for m in mkt]
cands += [[r, m] for r in reg_ for m in mkt]
print('hypotheses', len(cands))
sub = [('2018-07-01','2019-12-31'),('2020-01-01','2021-12-31'),('2022-01-01','2022-10-01')]
rows = []
t0 = time.time()
for parts in cands:
    ev = st.events(parts, DEV_EV)
    if len(ev) < 30: continue
    o = st.outcomes(ev); s = summarize(o)
    if s['coins'] < 4: continue
    sims = st.placebo_multi(ev, DEV_EV, draws=300); sims_r30 = sims[:,0]
    sims_dn = sims[:,1]
    z_r = (np.nanmean(sims_r30) - s['r30']) / np.nanstd(sims_r30)
    z_d = (s['dn20'] - np.nanmean(sims_dn)) / np.nanstd(sims_dn)
    # stability: mean r30 of events minus coin-day unconditional r30, per sub-period
    ex = []
    for a, b in sub:
        oo = o[(o.date >= a) & (o.date <= b)]
        if len(oo) >= 5:
            unc = np.mean([st.fwd[k].loc[a:b, 'r30'].mean() for k in oo.coin.unique()])
            ex.append(oo.r30.mean() - unc)
    s.update(parts='+'.join(parts), z_ret=z_r, z_dn=z_d, plc_r30=np.nanmean(sims_r30), plc_dn=np.nanmean(sims_dn),
             stab=sum(e < 0 for e in ex), stab_n=len(ex))
    rows.append(s)
R = pd.DataFrame(rows).sort_values('z_ret', ascending=False)
R.to_csv('../results/dev_scan_sell.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30)
print('time', round(time.time() - t0), 's, tested', len(R))
print(R.head(25)[['parts','n','dates','coins','r30','plc_r30','z_ret','dn20','plc_dn','z_dn','mdd60','mup60','stab','stab_n']].round(3).to_string(index=False))
print('z_ret>2:', (R.z_ret > 2).sum(), ' z_dn>2:', (R.z_dn > 2).sum(), ' of', len(R))
