import time
from common import *
from aoi import cycle as CY
cl = load('../data/closes.csv'); feats, conds = build_all(cl)
period = DEV; a, b = map(pd.Timestamp, period)

SELL = {
 'W_rsi':   ['s_rsi_hot','t_rsi_fall70'],
 'T_ema20': ['t_ema20_dn'],
 'T_low10_btc20': ['t_low10','m_btc_lt20'],
 'F_bb_low20': ['s_bb_out','t_low20'],
 'R_ema50_btc50': ['x_ema50_dn','m_btc_lt50'],
 'R_ema100_btcdd': ['x_ema100_dn','m_btc_dd10'],
}
REBUY = {
 'rsi_up30': ['r_rsi_up30'],
 'oversold+macd_up': ['r_oversold_recent','r_macd_up'],
 'reclaim20': ['r_reclaim_ema20'],
 'reclaim20+ema_up': ['r_reclaim_ema20','r_ema20_up'],
 'reclaim20+btc20': ['r_reclaim_ema20','r_btc_gt20'],
 'break_high20': ['r_break_high20'],
 'break_high20+btc20': ['r_break_high20','r_btc_gt20'],
 'golden': ['r_ema_golden'],
 'golden+btc20': ['r_ema_golden','r_btc_gt20'],
 'higher_low+ema_up': ['r_higher_low','r_ema20_up'],
 'btc20+rs20': ['r_btc_gt20','r_rs_gt20'],
 'btc20+ema_up+hl': ['r_btc_gt20','r_ema20_up','r_higher_low'],
 'macd_up+btc20': ['r_macd_up','r_btc_gt20'],
 'calm+reclaim20': ['r_vol_calm','r_reclaim_ema20'],
 'breadth_ok+reclaim20': ['r_breadth_ok','r_reclaim_ema20'],
 'deep30+rsi_up30': ['r_deep_dd30','r_rsi_up30'],
}
def pooled(sims, coins):
    df = pd.DataFrame({k: sims[k]['ret'] for k in coins}); pos = pd.DataFrame({k: sims[k]['pos'] for k in coins})
    hold = pd.DataFrame({k: sims[k]['hold'] for k in coins})
    return df, pos, hold
def run(coins, sellp, rebp, timeout, start, end):
    sims = {}
    for k in coins:
        sl = S.composite(conds[k], sellp); rb = None if rebp is None else S.composite(conds[k], rebp)
        sims[k] = CY.simulate(feats[k]['c'], sl, rb, start, end, timeout=timeout)
    return sims
def port_metrics(sims, coins):
    df, pos, hold = pooled(sims, coins)
    return CY.metrics(df.mean(axis=1).values), CY.metrics(hold.mean(axis=1).values), pos.values.mean()
def placebo(sims, coins, draws=200, seed=1):
    rng = np.random.default_rng(seed)
    n = min(len(sims[k]) for k in coins); res = []
    for _ in range(draws):
        off = int(rng.integers(30, n - 30)); cols = []
        for k in coins:
            s = sims[k]; pos = s['pos'].values; r = s['hold'].values
            ps = np.roll(pos, off)
            gross = np.r_[0.0, ps[:-1] * r[1:]]
            sw = np.abs(np.diff(np.r_[1.0, ps]))   # includes seam
            cols.append(gross - CY.COST * sw)
        res.append(CY.metrics(np.mean(cols, axis=0)))
    return pd.DataFrame(res)
