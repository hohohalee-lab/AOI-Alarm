"""Sell-alarm episodes: after a 매도·재진입형 sell alarm, how deep / how long was the dip before the prior peak was
reclaimed, and could a limit-style dip re-entry (instead of the breakout re-entry) have been done repeatedly?

Cycle windows (user's 4-year framing: 1 bear year + 3 bull years). Data only starts 2017-09, so tested:
  2019-01..2021-12  (bull of the 2018-21 cycle)   and   2023-01..2025-12  (bull of the 2022-25 cycle).
The 2015-17 bull is NOT testable here (no data before 2017-09).
Pre-declared dip levels (no picking of the best one afterwards): 5,10,15,20,25 % below the sell price. Cost 0.2%/side.
"""
from cyclelib import *
from aoi import cycle as CY
COINS = ['BTC', 'ETH', 'XRP', 'ADA', 'LINK', 'DOGE', 'SOL', 'AVAX', 'NEAR', 'SUI', 'ONDO']
cl = load('../data/closes.csv')
feats, conds = build_all(cl, coins=COINS)
WIN = {'2019-21 상승장': ('2019-01-01', '2021-12-31'), '2023-25 상승장': ('2023-01-01', '2025-12-31'),
       '참고:2026(하락)': ('2026-01-01', '2026-10-31')}
LEVELS = [0.05, 0.10, 0.15, 0.20, 0.25]
SELL = ['t_ema20_dn']; REBUY = ['r_break_high20', 'r_btc_gt20']; WARM = 60

def first_start(k, a):
    c = feats[k]['c']; return max(pd.Timestamp(a), c.index[0] + pd.Timedelta(days=WARM))

def episodes(k, a, b):
    """every B sell alarm in [a,b]; outcome measured on the full price history (so an episode may end after b)."""
    c = feats[k]['c']; s0 = first_start(k, a)
    if s0 >= pd.Timestamp(b): return []
    sims = CY.simulate(c, S.composite(conds[k], SELL), S.composite(conds[k], REBUY), s0, b, timeout=60)
    pos = sims['pos'].values; idx = sims.index; out = []
    for i in range(1, len(pos)):
        if pos[i - 1] == 1 and pos[i] == 0:
            d = idx[i]; ii = c.index.get_loc(d); Ps = c.iloc[ii]
            H = c.iloc[max(0, ii - 60): ii + 1].max()
            after = c.iloc[ii + 1:]
            brk = after[after > H]
            E = brk.index[0] if len(brk) else None
            seg = after.loc[:E] if E is not None else after
            if len(seg) == 0: continue
            tr_d = seg.idxmin(); tr = seg.min()
            bounce = after.loc[:tr_d].max() if tr_d > after.index[0] else np.nan
            j = i + 1
            while j < len(pos) and pos[j] == 0: j += 1
            rebuy_d = idx[j] if j < len(pos) else None
            rebuy_px = c.loc[rebuy_d] if rebuy_d is not None else np.nan
            out.append(dict(coin=k, sell=d, sell_px=Ps, prior_peak=H, peak_drop_at_sell=Ps / H - 1,
                            resolved=E is not None, reclaim=E, days_to_reclaim=(E - d).days if E is not None else np.nan,
                            trough_date=tr_d, days_to_trough=(tr_d - d).days, trough_vs_sell=tr / Ps - 1, trough_vs_peak=tr / H - 1,
                            bounce_before_trough=(bounce / Ps - 1) if bounce == bounce else np.nan,
                            price_at_reclaim_vs_sell=(c.loc[E] / Ps - 1) if E is not None else np.nan,
                            B_rebuy_date=rebuy_d, B_rebuy_vs_sell=(rebuy_px / Ps - 1) if rebuy_d is not None else np.nan))
    return out

def sim_dip(k, a, b, x, cost=CY.COST):
    """sell on EMA20-break alarm; re-buy when a close is <= sell*(1-x) (dip fill, conservative: at that close) OR, if the prior
       peak is reclaimed first, chase at that close ('miss'). Exit again only on the next alarm. Returns total return + trade list."""
    c = feats[k]['c']; s0 = first_start(k, a); cc = c.loc[s0:b]
    if len(cc) < 30: return None
    sl = S.edge(S.composite(conds[k], SELL).reindex(cc.index).fillna(False)).values
    v = cc.values; idx = cc.index
    eq = (1 - cost); inn = True; entry = v[0]; kind = 'start'; ent_i = 0; trades = []; fills = miss = 0; Ps = H = level = None
    for i in range(1, len(v)):
        if inn:
            if sl[i]:
                eq *= v[i] / entry * (1 - cost)
                trades.append(dict(kind=kind, buy=idx[ent_i], sell=idx[i], days=i - ent_i, ret=v[i] / entry * (1 - cost) * (1 - cost) - 1, worst=v[ent_i:i + 1].min() / entry - 1))
                inn = False; Ps = v[i]; gi = c.index.get_loc(idx[i]); H = c.iloc[max(0, gi - 60): gi + 1].max(); level = Ps * (1 - x)
        else:
            if v[i] <= level: fills += 1; kind = 'dip'
            elif v[i] > H: miss += 1; kind = 'chase'
            else: continue
            inn = True; entry = v[i]; ent_i = i; eq *= (1 - cost)
    open_ret = None
    if inn:
        eq *= v[-1] / entry; open_ret = dict(kind=kind, buy=idx[ent_i], days=len(v) - 1 - ent_i, ret=v[-1] / entry - 1, worst=v[ent_i:].min() / entry - 1)
    return dict(coin=k, eq=eq - 1, hold=v[-1] / v[0] - 1, fills=fills, miss=miss, sells=len(trades), trades=trades, open=open_ret, still_out=not inn)

def sim_B(k, a, b):
    c = feats[k]['c']; s0 = first_start(k, a)
    sm = CY.simulate(c, S.composite(conds[k], SELL), S.composite(conds[k], REBUY), s0, b, timeout=60)
    return CY.metrics(sm.ret.values)['total'], CY.metrics(sm.hold.values)['total']

if __name__ == '__main__':
    pd.set_option('display.width', 250); pd.set_option('display.max_columns', 40)
    allep = []
    for w, (a, b) in WIN.items():
        for k in COINS:
            for e in episodes(k, a, b): e['window'] = w; allep.append(e)
    E = pd.DataFrame(allep); E.to_csv('../results/dip_episodes.csv', index=False)
    print('episodes by window/coin'); print(E.groupby(['window', 'coin']).size().unstack(0).fillna(0).astype(int))
    summ = []
    for w in WIN:
        d = E[E.window == w]; r = d[d.resolved]
        for name, sub in (('전체', d), ('고점돌파 완료', r)):
            if len(sub) == 0: continue
            summ.append(dict(window=w, set=name, n=len(sub), coins=sub.coin.nunique(),
                             trough_med=sub.trough_vs_sell.median(), trough_p25=sub.trough_vs_sell.quantile(.25), trough_p75=sub.trough_vs_sell.quantile(.75), trough_worst=sub.trough_vs_sell.min(),
                             days_to_trough_med=sub.days_to_trough.median(), days_to_reclaim_med=sub.days_to_reclaim.median() if name != '전체' else np.nan,
                             never_below_sell=(sub.trough_vs_sell >= -0.0).mean(), dip_lt5=(sub.trough_vs_sell > -.05).mean(), dip_lt10=(sub.trough_vs_sell > -.10).mean(), dip_ge20=(sub.trough_vs_sell <= -.20).mean(),
                             unresolved=(~sub.resolved).sum(), B_rebuy_cheaper=(sub.B_rebuy_vs_sell < 0).mean()))
    S1 = pd.DataFrame(summ); S1.to_csv('../results/dip_summary.csv', index=False); print(S1.round(3).to_string(index=False))
    rows = []; LOOPS = []
    for w, (a, b) in WIN.items():
        for k in COINS:
            bt, ht = sim_B(k, a, b) if first_start(k, a) < pd.Timestamp(b) - pd.Timedelta(days=60) else (np.nan, np.nan)
            for x in LEVELS:
                r = sim_dip(k, a, b, x)
                if r is None: continue
                rows.append(dict(window=w, coin=k, x=x, dip_total=r['eq'], hold=r['hold'], B=bt, sells=r['sells'], fills=r['fills'], miss=r['miss']))
                for t in r['trades'] + ([r['open']] if r['open'] else []):
                    if t['kind'] != 'start': LOOPS.append(dict(window=w, coin=k, x=x, open=('sell' not in t), **{kk: vv for kk, vv in t.items() if kk != 'sell'}))
    R = pd.DataFrame(rows); R.to_csv('../results/dip_strategy.csv', index=False)
    g = R.groupby(['window', 'x']).agg(coins=('coin', 'nunique'), sells=('sells', 'sum'), fills=('fills', 'sum'), miss=('miss', 'sum'),
                                       dip_mean=('dip_total', 'mean'), dip_med=('dip_total', 'median'), B_mean=('B', 'mean'), hold_mean=('hold', 'mean'),
                                       beats_B=('dip_total', lambda s: np.nan), ).drop(columns='beats_B')
    g['beat_B_share'] = R.assign(w=R.dip_total > R.B).groupby(['window', 'x']).w.mean()
    g['beat_hold_share'] = R.assign(w=R.dip_total > R.hold).groupby(['window', 'x']).w.mean()
    g['fill_rate'] = g.fills / g.sells; print(g.round(3).to_string())
    g.to_csv('../results/dip_strategy_summary.csv')

    L = pd.DataFrame(LOOPS); L.to_csv('../results/dip_loops.csv', index=False)
    lg = L.groupby(['window', 'x', 'kind']).agg(n=('ret', 'size'), win=('ret', lambda s: (s > 0).mean()), med=('ret', 'median'), mean=('ret', 'mean'), worst_loop=('ret', 'min'),
                                                   days_med=('days', 'median'), days_max=('days', 'max'), worst_dd_med=('worst', 'median'), worst_dd=('worst', 'min'))
    print(lg.round(3).to_string()); lg.to_csv('../results/dip_loops_summary.csv')
    # medians for the strategy comparison (means are dominated by DOGE 2019-21 etc.)
    m = R.groupby(['window', 'x'])[['dip_total', 'B', 'hold']].median(); print(m.round(2).to_string())
    # chains: coins with >=2 consecutive completed dip loops
    ch = L[(L.kind == 'dip') & (~L.open)].groupby(['window', 'x', 'coin']).size().rename('dip_loops').reset_index()
    print(ch.groupby(['window', 'x']).dip_loops.agg(['count', 'sum', 'max']).to_string())
