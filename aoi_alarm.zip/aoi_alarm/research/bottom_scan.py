"""Chart-only search for local-bottom indicators (no sell alarm involved). Close-only data (no volume, no intraday low).
18 causal candidates declared in advance. Discovery 2018-07..2022-10 (5 alts), validation 2023-01..2026-07 (10 alts).
Pass rule (both periods): 30d mean return above common-shift placebo by z>2  AND  further 60d drop shallower than placebo by z>2."""
from events import *
cl = load('../data/closes.csv'); feats, conds = build_all(cl)
def add(k):
    f = feats[k]; c = f.c; d = conds[k]
    up = lambda s: s & ~s.shift(1, fill_value=False)
    dn_streak = (c < c.shift(1)).astype(int); run = dn_streak.groupby((dn_streak == 0).cumsum()).cumsum()
    rsi_up30 = (f.rsi > 30) & (f.rsi.shift(1) <= 30)
    cand = {
     'RSI<30': f.rsi < 30, 'RSI<25': f.rsi < 25, 'RSI 30 상향돌파': rsi_up30,
     '볼린저 하단 이탈': c < f.bb_lo, 'EMA20 대비 -15%↓': f.dist20 <= -0.15,
     '60일고점 -30%↓': f.dd60 <= -0.30, '60일고점 -40%↓': f.dd60 <= -0.40, '60일고점 -50%↓': f.dd60 <= -0.50,
     '7일 -20%↓': c / c.shift(7) - 1 <= -0.20, '5일 연속 하락': run >= 5, '7일 연속 하락': run >= 7,
     '변동성 상위10%+EMA20 -10%↓': (f.rv_pct >= 0.9) & (f.dist20 <= -0.10),
     'MACD 히스토그램 바닥 반등': (f.macd_hist < 0) & (f.macd_hist > f.macd_hist.shift(1)) & (f.macd_hist.shift(1) <= f.macd_hist.shift(2)),
     '10일 저점 상승(higher low)': f.hl10.astype(bool),
     'EMA10 회복(10일 중 8일 이하)': (c > f.ema10) & ((c.shift(1) <= f.ema10.shift(1)).rolling(10).sum() >= 8),
     'RSI<30(최근10일)+higher low': (f.rsi.rolling(10).min() < 30) & f.hl10.astype(bool),
     '60일고점 -30%↓+RSI30 상향(5일)': (f.dd60 <= -0.30) & rsi_up30.rolling(5).max().astype(bool),
     'RSI<30(최근5일)+EMA10 회복': (f.rsi.rolling(5).min() < 30) & (c > f.ema10)}
    for n, s in cand.items(): d[n] = s.fillna(False).astype(bool)
for k in feats: add(k)
NAMES = ['RSI<30', 'RSI<25', 'RSI 30 상향돌파', '볼린저 하단 이탈', 'EMA20 대비 -15%↓', '60일고점 -30%↓', '60일고점 -40%↓', '60일고점 -50%↓', '7일 -20%↓', '5일 연속 하락', '7일 연속 하락',
         '변동성 상위10%+EMA20 -10%↓', 'MACD 히스토그램 바닥 반등', '10일 저점 상승(higher low)', 'EMA10 회복(10일 중 8일 이하)', 'RSI<30(최근10일)+higher low', '60일고점 -30%↓+RSI30 상향(5일)', 'RSI<30(최근5일)+EMA10 회복']
PER = {'발견 2018-22': (ALTS_LONG, ('2018-07-01', '2022-10-01')), '검증 2023-26': (ALTS_ALL, ('2023-01-01', '2026-07-01'))}
rows = []
for pn, (coins, per) in PER.items():
    st = Study(cl, feats, conds, coins)
    # unconditional baseline over valid coin-days
    A = st._arr(per); allv = np.vstack([v[1] for v in A.values()]); base = np.nanmean(allv, axis=0)
    for nm in NAMES:
        ev = st.events([nm], per, cooldown=10)
        if len(ev) < 25: rows.append(dict(period=pn, cond=nm, n=len(ev))); continue
        o = st.outcomes(ev); sims = st.placebo_multi(ev, per, cols=(0, 3, 5), draws=300)
        r30, dn20, mdd = o.r30.mean(), o.dn20.mean(), o.mdd60.mean()
        rows.append(dict(period=pn, cond=nm, n=len(ev), dates=o.date.nunique(), coins=o.coin.nunique(), r30=r30, plc_r30=sims[:, 0].mean(), z_r30=(r30 - sims[:, 0].mean()) / sims[:, 0].std(),
                         dn20=dn20, plc_dn20=sims[:, 1].mean(), mdd60=mdd, plc_mdd60=sims[:, 2].mean(), z_mdd=(mdd - sims[:, 2].mean()) / sims[:, 2].std(),
                         further_drop10=(o.mdd60 <= -0.10).mean(), base_further_drop10=np.nanmean(allv[:, 5] <= -0.10)))
R = pd.DataFrame(rows); R.to_csv('../results/bottom_scan.csv', index=False)
pd.set_option('display.width', 250); print(R.round(3).to_string(index=False))
P = R.pivot(index='cond', columns='period', values=['z_r30', 'z_mdd'])
ok = P[(P[('z_r30', '발견 2018-22')] > 2) & (P[('z_mdd', '발견 2018-22')] > 2) & (P[('z_r30', '검증 2023-26')] > 2) & (P[('z_mdd', '검증 2023-26')] > 2)]
print('\nPASS both periods:', list(ok.index)); print(P.round(2).to_string())
