from cyclelib import *
rows = []; t0 = time.time()
for sn, sp in SELL.items():
    for rn, rp in list(REBUY.items()):
        for to in (None, 60):
            sims = run(ALTS_LONG, sp, rp, to, a, b)
            m, h, expo = port_metrics(sims, ALTS_LONG)
            pl = placebo(sims, ALTS_LONG, draws=100)
            rows.append(dict(sell=sn, rebuy=rn, timeout=to, total=m['total'], mdd=m['mdd'], hold_total=h['total'], hold_mdd=h['mdd'], expo=expo,
                             z_total=(m['total'] - pl.total.mean()) / pl.total.std(), plc_total=pl.total.mean(), z_mdd=(m['mdd'] - pl.mdd.mean()) / pl.mdd.std(),
                             switches=int(sum(np.abs(np.diff(sims[k]['pos'])).sum() for k in ALTS_LONG))))
R = pd.DataFrame(rows).sort_values('z_total', ascending=False); R.to_csv('../results/dev_scan_cycle.csv', index=False)
pd.set_option('display.width', 250)
print('time', round(time.time() - t0), 's; hypotheses', len(R))
print('DEV hold total %.2f mdd %.2f' % (R.hold_total.iloc[0], R.hold_mdd.iloc[0]))
print(R.head(15).round(3).to_string(index=False))
print('z_total>2:', (R.z_total > 2).sum(), ' z_total>1.64:', (R.z_total > 1.64).sum(), ' of', len(R))
print('best by MDD:'); print(R.sort_values('mdd', ascending=False).head(5).round(3).to_string(index=False))
