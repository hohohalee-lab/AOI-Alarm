import json
from cyclelib import *
dev = pd.read_csv('../results/dev_scan_cycle.csv')
# ---- FREEZE: for each sell family, the rebuy (and timeout) with best dev z_total. No other selection after this point.
frozen = {}
for sn, g in dev.groupby('sell'):
    r = g.sort_values('z_total', ascending=False).iloc[0]
    frozen[sn] = dict(sell=SELL[sn], rebuy=REBUY[r.rebuy], rebuy_name=r.rebuy, timeout=None if pd.isna(r.timeout) else int(r.timeout),
                      dev_z=float(r.z_total), dev_total=float(r.total), dev_mdd=float(r.mdd))
json.dump(frozen, open('../results/frozen_cycle_configs.json', 'w'), indent=1, ensure_ascii=False)
print('FROZEN (chosen on 2018-07..2022-12 only):')
for k, v in frozen.items(): print(' ', k, '| rebuy:', v['rebuy_name'], '| timeout', v['timeout'], '| dev z %.1f total %.1f mdd %.2f' % (v['dev_z'], v['dev_total'], v['dev_mdd']))

# ---- VALIDATE on 2023-01-01..2026-10-31, all 10 alts (each from its listing)
a, b = map(pd.Timestamp, VAL)
def val_run(coins, cfg, start, end):
    return run(coins, cfg['sell'], cfg['rebuy'], cfg['timeout'], start, end)
def pooled_avail(sims, coins):
    df = pd.DataFrame({k: sims[k]['ret'] for k in coins}); h = pd.DataFrame({k: sims[k]['hold'] for k in coins})
    return df.mean(axis=1), h.mean(axis=1)       # equal weight over coins listed on that date (NaN skipped)
rows = []; per_year = []; percoin = []
for name, cfg in frozen.items():
    sims = {}
    for k in ALTS_ALL:
        c = feats[k]['c']; st = max(a, c.index[0] + pd.Timedelta(days=200))
        sims[k] = CY.simulate(c, S.composite(conds[k], cfg['sell']), S.composite(conds[k], cfg['rebuy']), st, b, timeout=cfg['timeout'])
    sr, hr = pooled_avail(sims, ALTS_ALL)
    m, h = CY.metrics(sr.values), CY.metrics(hr.values)
    # placebo: common circular shift of positions (aligned on the pooled calendar)
    rng = np.random.default_rng(42); pl = []
    posdf = pd.DataFrame({k: sims[k]['pos'] for k in ALTS_ALL}); rdf = pd.DataFrame({k: sims[k]['hold'] for k in ALTS_ALL}); idx = posdf.index
    n = len(idx)
    for _ in range(300):
        off = int(rng.integers(30, n - 30)); cols = {}
        for k in ALTS_ALL:
            p = posdf[k].dropna(); r = rdf[k].reindex(p.index); m_ = len(p)
            ps = np.roll(p.values, off % m_); g = np.r_[0.0, ps[:-1] * r.values[1:]]
            sw = np.abs(np.diff(np.r_[1.0, ps])); cols[k] = pd.Series(g - CY.COST * sw, index=p.index)
        pl.append(CY.metrics(pd.DataFrame(cols).mean(axis=1).values))
    pl = pd.DataFrame(pl)
    z = (m['total'] - pl.total.mean()) / pl.total.std(); zm = (m['mdd'] - pl.mdd.mean()) / pl.mdd.std()
    pv = (pl.total >= m['total']).mean()
    expo = float(posdf.mean().mean())
    rows.append(dict(name=name, rebuy=cfg['rebuy_name'], timeout=cfg['timeout'], total=m['total'], mdd=m['mdd'], hold_total=h['total'], hold_mdd=h['mdd'],
                     plc_total=pl.total.mean(), plc_mdd=pl.mdd.mean(), z_total=z, p_total=pv, z_mdd=zm, expo=expo,
                     switches=int(sum(np.abs(np.diff(sims[k]['pos'])).sum() for k in ALTS_ALL)),
                     pass_rule=bool(z > 2.4 and m['mdd'] > h['mdd'])))
    for y in (2023, 2024, 2025, 2026):
        msk = sr.index.year == y
        per_year.append(dict(name=name, year=y, strat=CY.metrics(sr[msk].values)['total'], hold=CY.metrics(hr[msk].values)['total'],
                             strat_mdd=CY.metrics(sr[msk].values)['mdd'], hold_mdd=CY.metrics(hr[msk].values)['mdd']))
    for k in ALTS_ALL:
        s = sims[k]; percoin.append(dict(name=name, coin=k, strat=CY.metrics(s['ret'].values)['total'], hold=CY.metrics(s['hold'].values)['total'],
                                         strat_mdd=CY.metrics(s['ret'].values)['mdd'], hold_mdd=CY.metrics(s['hold'].values)['mdd']))
V = pd.DataFrame(rows); V.to_csv('../results/val_cycle.csv', index=False)
Y = pd.DataFrame(per_year); Y.to_csv('../results/val_cycle_by_year.csv', index=False)
P = pd.DataFrame(percoin); P.to_csv('../results/val_cycle_by_coin.csv', index=False)
pd.set_option('display.width', 250)
print('\nVALIDATION 2023-01..2026-10 (pooled equal-weight, 10 alts):')
print(V.round(3).to_string(index=False))
print('\nBy year (strategy total / hold total):')
print(Y.pivot(index='name', columns='year', values=['strat', 'hold']).round(2).to_string())
print('\nper-coin: share of coins where strategy beat hold total / had smaller mdd')
print(P.assign(win=P.strat > P.hold, mddwin=P.strat_mdd > P.hold_mdd).groupby('name')[['win', 'mddwin']].mean().round(2).to_string())
