import numpy as np, pandas as pd
from common import *

H = (30, 60, 90)

def fwd_table(c: pd.Series) -> pd.DataFrame:
    """Forward outcomes from close of day t (fill = close t). Needs future closes -> evaluation only."""
    a = c.values; n = len(a)
    out = np.full((n, 8), np.nan)
    for i in range(n):
        p0 = a[i]
        for j, h in enumerate(H):
            if i + h < n: out[i, j] = a[i + h] / p0 - 1
        if i + 60 < n:
            f = a[i + 1:i + 61] / p0
            dn = np.flatnonzero(f <= .8); up = np.flatnonzero(f >= 1.2)
            di = dn[0] if len(dn) else 10**9; ui = up[0] if len(up) else 10**9
            out[i, 3] = float(di < ui); out[i, 4] = float(ui < di)
            out[i, 5] = f.min() - 1; out[i, 6] = f.max() - 1
    return pd.DataFrame(out, index=c.index, columns=['r30', 'r60', 'r90', 'dn20', 'up20', 'mdd60', 'mup60', '_'])

class Study:
    def __init__(self, closes, feats, conds, coins):
        self.coins = coins; self.conds = conds; self.feats = feats
        self.fwd = {k: fwd_table(closes[k].dropna()) for k in coins}

    def level(self, k, parts):
        return S.composite(self.conds[k], parts)

    def events(self, parts, period, cooldown=14, last_fwd_ok='r90'):
        a, b = map(pd.Timestamp, period)
        rows = []
        for k in self.coins:
            lv = self.level(k, parts)
            for t in S.events(lv, cooldown):
                if a <= t <= b and not np.isnan(self.fwd[k].at[t, last_fwd_ok]):
                    rows.append((k, t))
        return rows

    def outcomes(self, ev):
        if not ev: return pd.DataFrame()
        return pd.DataFrame([self.fwd[k].loc[t, ['r30', 'r60', 'r90', 'dn20', 'up20', 'mdd60', 'mup60']].astype(float).rename((k, t)) for k, t in ev]).assign(
            coin=[k for k, _ in ev], date=[t for _, t in ev])

    def valid_index(self, k, period, last_fwd_ok='r90'):
        a, b = map(pd.Timestamp, period)
        f = self.fwd[k]; idx = f.index[(f.index >= a) & (f.index <= b) & f[last_fwd_ok].notna()]
        return idx

    def placebo(self, ev, period, stat, draws=300, seed=0, last_fwd_ok='r90'):
        """shift every event of every coin by the same k days (wrapping inside that coin's valid index)."""
        rng = np.random.default_rng(seed)
        vi = {k: self.valid_index(k, period, last_fwd_ok) for k in self.coins}
        pos = {}
        for k, t in ev:
            if t in vi[k]: pos.setdefault(k, []).append(vi[k].get_loc(t))
        span = max(len(v) for v in vi.values())
        sims = []
        for _ in range(draws):
            off = int(rng.integers(30, span - 30))
            sh = []
            for k, ps in pos.items():
                n = len(vi[k])
                for p in ps: sh.append((k, vi[k][(p + off) % n]))
            sims.append(stat(self.outcomes(sh)))
        return np.array(sims)

    def _arr(self, period, last_fwd_ok='r90'):
        key = (period, last_fwd_ok)
        if not hasattr(self, '_cache'): self._cache = {}
        if key not in self._cache:
            d = {}
            for k in self.coins:
                vi = self.valid_index(k, period, last_fwd_ok)
                d[k] = (vi, self.fwd[k].loc[vi, ['r30', 'r60', 'r90', 'dn20', 'up20', 'mdd60', 'mup60']].values)
            self._cache[key] = d
        return self._cache[key]

    def placebo_multi(self, ev, period, cols=(0, 3), draws=300, seed=0, last_fwd_ok='r90'):
        """Fast: returns array (draws, len(cols)) of mean outcomes under common-shift placebo."""
        rng = np.random.default_rng(seed)
        A = self._arr(period, last_fwd_ok)
        pos = {}
        for k, t in ev:
            vi = A[k][0]
            if t in vi: pos.setdefault(k, []).append(vi.get_loc(t))
        pos = {k: np.array(v) for k, v in pos.items()}
        span = max(len(v[0]) for v in A.values())
        out = np.empty((draws, len(cols)))
        for d in range(draws):
            off = int(rng.integers(30, span - 30))
            acc = []
            for k, ps in pos.items():
                n = len(A[k][0]); acc.append(A[k][1][(ps + off) % n][:, list(cols)])
            out[d] = np.vstack(acc).mean(axis=0)
        return out

def summarize(o):
    if len(o) == 0: return {}
    return dict(n=len(o), dates=o.date.nunique(), coins=o.coin.nunique(),
                r30=o.r30.mean(), r30_med=o.r30.median(), r60=o.r60.mean(), r90=o.r90.mean(),
                p_down30=(o.r30 < 0).mean(), dn20=o.dn20.mean(), up20=o.up20.mean(), mdd60=o.mdd60.mean(), mup60=o.mup60.mean())

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k / n; d = 1 + z * z / n; c = p + z * z / (2 * n); w = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((c - w) / d, (c + w) / d)
