import json, pandas as pd, numpy as np
R='results/'
E=pd.read_csv(R+'dip_episodes.csv',parse_dates=['sell'])
E=E.sort_values(['window','sell','coin'],ascending=[True,False,True])
def f(x,d=1): return None if pd.isna(x) else round(float(x),d)
rows=[[r.window,r.coin,r.sell.strftime('%Y-%m-%d'),f(r.sell_px,4),f(r.trough_vs_sell*100),int(r.days_to_trough),f(r.bounce_before_trough*100),None if pd.isna(r.days_to_reclaim) else int(r.days_to_reclaim),f(r.B_rebuy_vs_sell*100)] for r in E.itertuples()]
S=pd.read_csv(R+'dip_summary.csv'); G=pd.read_csv(R+'dip_strategy_summary.csv'); L=pd.read_csv(R+'dip_loops_summary.csv')
Rr=pd.read_csv(R+'dip_strategy.csv'); med=Rr.groupby(['window','x'])[['dip_total','B','hold']].median().reset_index()
pc=E[E.window!='참고:2026(하락)'].groupby(['window','coin']).agg(n=('coin','size'),res=('resolved','mean'),tr=('trough_vs_sell','median'),dtr=('days_to_trough','median'),rec=('days_to_reclaim','median'),worst=('trough_vs_sell','min'),nb=('trough_vs_sell',lambda s:(s>=0).mean())).reset_index()
data=dict(rows=rows,summary=S.round(4).to_dict('records'),strat=G.round(4).to_dict('records'),med=med.round(4).to_dict('records'),loops=L.round(4).to_dict('records'),percoin=pc.round(4).to_dict('records'))
html=open('research/dip_template.html',encoding='utf-8').read().replace('__DATA__',json.dumps(data,ensure_ascii=False))
open('/tmp/claude-0/-home-claude/e9d37770-3860-5a0e-9db5-840285d3acad/scratchpad/dip_page.html','w',encoding='utf-8').write(html); print(len(html), len(rows))
