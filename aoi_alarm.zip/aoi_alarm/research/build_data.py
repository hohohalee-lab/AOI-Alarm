"""Build spliced daily close panel. CM (Coin Metrics) before Coinbase start, Coinbase after.
Usage: python build_data.py <cm_dir> <coinbase_json_dir> <out_csv>"""
import sys, json
import pandas as pd, numpy as np
cm_dir, cb_dir, out = sys.argv[1:4]
LONG = ['btc','eth','xrp','ada','link','doge']
ALL = ['BTC','ETH','XRP','ADA','LINK','DOGE','SOL','AVAX','NEAR','SUI','ONDO']
series = {}
for s in ALL:
    cb = pd.DataFrame(json.load(open(f'{cb_dir}/{s}.json'))['rows'], columns=['date','o','h','l','c','v'])
    cb['date'] = pd.to_datetime(cb['date']); cb = cb.set_index('date').astype(float)
    c = cb['c']
    if s.lower() in LONG:
        cm = pd.read_csv(f'{cm_dir}/{s.lower()}.csv', usecols=['time','PriceUSD'], parse_dates=['time']).dropna().set_index('time')['PriceUSD']
        cm = cm[cm.index >= '2017-09-01']
        first = c.index[0]
        factor = c.iloc[0] / cm.loc[first]
        pre = cm[cm.index < first] * factor
        c = pd.concat([pre, c])
    series[s] = c
df = pd.DataFrame(series).sort_index()
df.index.name = 'date'
df.to_csv(out)
print(df.notna().sum().to_string()); print(df.apply(lambda x: x.first_valid_index()).to_string())
# 24/7 check: next open vs prior close on Coinbase data
for s in ['ETH','SOL']:
    cb = pd.DataFrame(json.load(open(f'{cb_dir}/{s}.json'))['rows'], columns=['date','o','h','l','c','v']).astype({'o':float,'c':float})
    r = (cb.o.shift(-1)/cb.c - 1).dropna()
    print(s,'next-open vs close: mean %.5f  median|.| %.5f  p99|.| %.4f' % (r.mean(), r.abs().median(), r.abs().quantile(.99)))
