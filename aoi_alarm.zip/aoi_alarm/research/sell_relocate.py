"""Redo of the sell-alarm search restricted to the user's bull years (2020, 2021, 2023, 2024, 2025; 2016-17 not in data).
Goal (user): alarm placed where a lower close appears afterwards with higher probability than today's EMA20-break (~84%), without being much later.
Reported for every declared trigger (no picking): P(lower close after alarm before prior 60d peak is reclaimed), depth, how late (drop from peak at alarm),
and the full sell->breakout re-entry cycle result vs hold in the same years."""
from cyclelib import *
from aoi import cycle as CY
COINS = ['BTC', 'ETH', 'XRP', 'ADA', 'LINK', 'DOGE', 'SOL', 'AVAX', 'NEAR', 'SUI', 'ONDO']
cl = load('../data/closes.csv'); feats, conds = build_all(cl, coins=COINS)
YW = {'2020-21': ('2020-01-01', '2021-12-31'), '2023-25': ('2023-01-01', '2025-12-31')}
REBUY = ['r_break_high20', 'r_btc_gt20']; WARM = 60
def rec(s, n): return s.rolling(n, min_periods=1).max().astype(bool)
def trig(k):
    f = feats[k]; d = conds[k]; c = f.c; e20 = d.t_ema20_dn.astype(bool)
    return {
     '현재: EMA20 하향 이탈': e20,
     'EMA10 하향 이탈': d.t_ema10_dn.astype(bool), '10일 최저 종가 이탈': d.t_low10.astype(bool), '20일 최저 종가 이탈': d.t_low20.astype(bool),
     'EMA10<EMA20 데드크로스': d.t_ema_dead.astype(bool), 'MACD 히스토그램 음전환': d.t_macd_dn.astype(bool), '60일고점 -15% 도달': d.t_dd15.astype(bool),
     'RSI 70 하향 이탈': d.t_rsi_fall70.astype(bool),
     'X1 EMA20 이탈 + 5일 저점 하향(3일 내)': rec(e20, 3) & (c < c.shift(1).rolling(5).min()),
     'X2 EMA20 이탈 + RSI<50': e20 & (f.rsi < 50),
     'X3 EMA20 이탈 + EMA20 기울기 하락': e20 & (f.ema20 < f.ema20.shift(3)),
     'X4 2일 연속 EMA20 아래': (c < f.ema20) & (c.shift(1) < f.ema20.shift(1)),
     'X5 EMA10 이탈 + EMA10<EMA20': d.t_ema10_dn.astype(bool) & (f.ema10 < f.ema20),
     'X6 EMA20 이탈 + 고점 대비 -10%↓': e20 & (f.dd60 <= -0.10),
     'X7 EMA20 이탈 + 고점 대비 -10% 이내(초기)': e20 & (f.dd60 > -0.10),
     'X8 10일 저점 이탈 + EMA20 아래': d.t_low10.astype(bool) & (c < f.ema20)}
TR = {k: trig(k) for k in COINS}; NAMES = list(TR['BTC'].keys())
reb = {k: S.composite(conds[k], REBUY) for k in COINS}
def first_start(k, a): return max(pd.Timestamp(a), feats[k].c.index[0] + pd.Timedelta(days=WARM))
rows = []; eps = []
for nm in NAMES:
    for w, (a, b) in YW.items():
        for k in COINS:
            c = feats[k].c; s0 = first_start(k, a)
            if s0 >= pd.Timestamp(b) - pd.Timedelta(days=90): continue
            sm = CY.simulate(c, TR[k][nm], reb[k], s0, b, timeout=60)
            pos = sm.pos.values; idx = sm.index
            for i in range(1, len(pos)):
                if pos[i - 1] == 1 and pos[i] == 0:
                    d = idx[i]; ii = c.index.get_loc(d); Ps = c.iloc[ii]; H = c.iloc[max(0, ii - 60): ii + 1].max(); after = c.iloc[ii + 1:]
                    brk = after[after > H]; E = brk.index[0] if len(brk) else None; seg = after.loc[:E] if E is not None else after
                    if len(seg) == 0: continue
                    eps.append(dict(trig=nm, win=w, coin=k, sell=d, year=d.year, trough=seg.min() / Ps - 1, days_tr=(seg.idxmin() - d).days, late=Ps / H - 1, reclaimed=E is not None))
            m = CY.metrics(sm.ret.values); h = CY.metrics(sm.hold.values)
            rows.append(dict(trig=nm, win=w, coin=k, total=m['total'], mdd=m['mdd'], hold=h['total'], hold_mdd=h['mdd'], yrs=(pd.Timestamp(b) - s0).days / 365))
Ep = pd.DataFrame(eps); Cy = pd.DataFrame(rows); Ep.to_csv('../results/relocate_episodes.csv', index=False); Cy.to_csv('../results/relocate_cycle.csv', index=False)
out = []
for nm in NAMES:
    e = Ep[Ep.trig == nm]; cy = Cy[Cy.trig == nm]
    out.append(dict(trigger=nm, alarms=len(e), per_coin_year=len(e) / cy.yrs.sum(), lower_any=(e.trough < 0).mean(), lower_1=(e.trough <= -.01).mean(), lower_5=(e.trough <= -.05).mean(), lower_10=(e.trough <= -.10).mean(),
                    med_trough=e.trough.median(), late_med=e.late.median(), unreclaimed=(~e.reclaimed).mean(), cycle_med=cy.total.median(), hold_med=cy.hold.median(), cycle_mdd=cy.mdd.median(), hold_mdd=cy.hold_mdd.median(),
                    beats_hold=(cy.total > cy.hold).mean()))
O = pd.DataFrame(out); O.to_csv('../results/relocate_summary.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_columns', 30); print(O.round(3).to_string(index=False))
