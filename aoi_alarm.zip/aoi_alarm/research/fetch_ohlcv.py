"""Download 4-hour OHLCV (open/high/low/close/volume) for research. Meant to run in GitHub Actions (this sandbox cannot reach exchanges).
Sources tried in order per coin (USDT pairs): Binance market-data mirror -> Binance -> OKX.  Upbit KRW 4h is fetched separately (the exchange the user trades on).
Output: research_data/ohlcv_4h.csv.gz  (columns: source,symbol,open_time_utc,open,high,low,close,volume)  +  research_data/coverage.txt
Env overrides (used by the mock test): BINANCE_BASES, OKX_BASE, UPBIT_BASE, OUT_DIR, SINCE."""
import os, sys, time, json, gzip, io, urllib.request, urllib.parse
from datetime import datetime, timezone
import pandas as pd
COINS = os.environ.get('COINS', 'BTC,ETH,XRP,ADA,LINK,DOGE,SOL,AVAX,NEAR,SUI,ONDO,RENDER,ENA,WLD,AXL').split(',')
RETRY = float(os.environ.get('RETRY_SLEEP', '1.5')); PAUSE = float(os.environ.get('PAUSE', '0.15'))
BINANCE_BASES = os.environ.get('BINANCE_BASES', 'https://data-api.binance.vision,https://api.binance.com').split(',')
OKX_BASE = os.environ.get('OKX_BASE', 'https://www.okx.com'); UPBIT_BASE = os.environ.get('UPBIT_BASE', 'https://api.upbit.com')
OUT = os.environ.get('OUT_DIR', 'research_data'); SINCE = pd.Timestamp(os.environ.get('SINCE', '2017-08-01'), tz='UTC')
H4 = 4 * 3600 * 1000

def get(url, tries=4):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'aoi-research/1.0'})
            with urllib.request.urlopen(req, timeout=25) as r: return json.loads(r.read().decode())
        except Exception as ex:
            err = ex; time.sleep(RETRY * (i + 1))
    raise RuntimeError(f'{url} -> {err}')

def binance(base, sym):
    rows = []; t = int(SINCE.timestamp() * 1000); end = int(time.time() * 1000)
    while t < end:
        d = get(f'{base}/api/v3/klines?symbol={sym}USDT&interval=4h&limit=1000&startTime={t}')
        if not d: break
        rows += [(x[0], x[1], x[2], x[3], x[4], x[5]) for x in d]
        nt = d[-1][0] + H4
        if nt <= t: break
        t = nt
        if len(d) < 2: break
        time.sleep(PAUSE)
    return rows

def okx(sym):
    rows = []; after = int(time.time() * 1000) + H4
    while True:
        d = get(f'{OKX_BASE}/api/v5/market/history-candles?instId={sym}-USDT&bar=4H&limit=100&after={after}').get('data', [])
        if not d: break
        rows += [(int(x[0]), x[1], x[2], x[3], x[4], x[5]) for x in d if x[8] == '1']
        after = int(d[-1][0])
        if after <= SINCE.timestamp() * 1000: break
        time.sleep(PAUSE)
    return sorted(rows)

def upbit(sym):
    rows = []; to = None
    while True:
        u = f'{UPBIT_BASE}/v1/candles/minutes/240?market=KRW-{sym}&count=200' + (f'&to={urllib.parse.quote(to)}' if to else '')
        d = get(u)
        if not d: break
        for x in d:
            ts = int(datetime.strptime(x['candle_date_time_utc'], '%Y-%m-%dT%H:%M:%S').replace(tzinfo=timezone.utc).timestamp() * 1000)
            rows.append((ts, x['opening_price'], x['high_price'], x['low_price'], x['trade_price'], x['candle_acc_trade_volume']))
        oldest = d[-1]['candle_date_time_utc']
        if len(d) < 200 or pd.Timestamp(oldest, tz='UTC') <= SINCE: break
        to = oldest; time.sleep(PAUSE)   # Upbit 'to' is exclusive
    return sorted(set(rows))

def frame(rows, source, sym):
    df = pd.DataFrame(rows, columns=['ms', 'open', 'high', 'low', 'close', 'volume']).drop_duplicates('ms').sort_values('ms')
    df[['open', 'high', 'low', 'close', 'volume']] = df[['open', 'high', 'low', 'close', 'volume']].astype(float)
    df.insert(0, 'open_time_utc', pd.to_datetime(df.pop('ms'), unit='ms', utc=True)); df.insert(0, 'symbol', sym); df.insert(0, 'source', source)
    return df[df.open_time_utc >= SINCE]

def main():
    parts = []; log = []
    for sym in COINS:
        got = None
        for base in BINANCE_BASES:
            try:
                r = binance(base, sym)
                if len(r) > 50: got = ('binance', r); break
            except Exception as ex: log.append(f'{sym} binance {base}: {str(ex)[:120]}')
        if got is None:
            try:
                r = okx(sym)
                if len(r) > 50: got = ('okx', r)
            except Exception as ex: log.append(f'{sym} okx: {str(ex)[:120]}')
        if got: parts.append(frame(got[1], got[0] + '_usdt', sym))
        else: log.append(f'{sym}: NO USDT DATA')
        try:
            r = upbit(sym)
            if len(r) > 50: parts.append(frame(r, 'upbit_krw', sym))
        except Exception as ex: log.append(f'{sym} upbit: {str(ex)[:120]}')
        print('done', sym, flush=True)
    os.makedirs(OUT, exist_ok=True)
    if not parts: print('NOTHING DOWNLOADED'); open(f'{OUT}/coverage.txt', 'w').write('NOTHING DOWNLOADED\n' + '\n'.join(log)); sys.exit(1)
    D = pd.concat(parts); D.to_csv(f'{OUT}/ohlcv_4h.csv.gz', index=False, compression='gzip')
    cov = D.groupby(['source', 'symbol']).open_time_utc.agg(['min', 'max', 'count'])
    txt = cov.to_string() + '\n\nproblems:\n' + ('\n'.join(log) if log else 'none')
    open(f'{OUT}/coverage.txt', 'w').write(txt); print(txt)
if __name__ == '__main__': main()
