"""Derive the numbers quoted inside alerts from the research CSVs (single source of truth)."""
import json
import pandas as pd, numpy as np
R = '../results/'
v = pd.read_csv(R + 'val_round_trips.csv', parse_dates=['sell', 'buy']); d = pd.read_csv(R + 'dev_round_trips.csv', parse_dates=['sell', 'buy'])
cyc = pd.read_csv(R + 'val_cycle.csv'); row = cyc[cyc.name == 'T_ema20'].iloc[0]
coin = pd.read_csv(R + 'val_by_coin_B.csv')
J = pd.read_csv(R + 'joint_tables.csv')
def jt(fam, split, k):
    r = J[(J.family == fam) & (J.split == split) & (J.k == k)].iloc[0]; return r
def trip(x):
    net = x.chg - .004
    return dict(trips=int(len(x)), cheaper_pct=float((net < 0).mean()), median_chg=float(x.chg.median()), median_days_out=float(x.days.median()),
                after30_below_pct=float((x.after30 < 0).mean()), timeout_pct=float((x.kind == 'timeout').mean()))
A_val = jt('A_매도온리(국면이탈)', 'val', 2); A_dev = jt('A_매도온리(국면이탈)', 'dev', 2)
stats = dict(
  universe_validated=['ETH', 'XRP', 'ADA', 'LINK', 'DOGE', 'SOL', 'AVAX', 'NEAR', 'SUI', 'ONDO'],
  B=dict(name_ko='매도·재진입형(추세순환)', confidence='검증 통과(사전기준) · 단, 체결지연·비용에 민감', val_period='2023-01~2026-10',
         val=trip(v), dev=trip(d),
         pooled=dict(strategy_total=float(row.total), hold_total=float(row.hold_total), strategy_mdd=float(row.mdd), hold_mdd=float(row.hold_mdd), in_market=float(row.expo), z_vs_random=float(row.z_total)),
         coins_beating_hold=int((coin.strat > coin.hold).sum()), coins_lower_mdd=int((coin.strat_mdd > coin.hold_mdd).sum()), coins=int(len(coin))),
  A=dict(name_ko='매도전용형(국면이탈)', confidence='참고용 · 약한 근거(검증 구간에서 일부만 유의)',
         val=dict(n=int(A_val.n), dates=int(A_val.dates), r30=float(A_val.r30), plc_r30=float(A_val.plc_r30), r90=float(A_val.r90), plc_r90=float(A_val.plc_r90), p_r30=float(A_val.p_r30), dn20=float(A_val.dn20), plc_dn=float(A_val.plc_dn)),
         dev=dict(n=int(A_dev.n), dates=int(A_dev.dates), r30=float(A_dev.r30), plc_r30=float(A_dev.plc_r30), r90=float(A_dev.r90), plc_r90=float(A_dev.plc_r90), p_r30=float(A_dev.p_r30))),
)
json.dump(stats, open('../config/stats.json', 'w'), indent=1, ensure_ascii=False)
print(json.dumps(stats, indent=1, ensure_ascii=False))
