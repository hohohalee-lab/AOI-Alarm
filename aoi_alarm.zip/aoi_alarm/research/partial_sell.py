"""Partial-sell test: at each B sell alarm sell fraction f of the position, buy the same fraction back at the B re-entry.
Equivalent to a (1-f) buy&hold sleeve + f sleeve following the full B strategy (no rebalancing between them)."""
from cyclelib import *
from aoi import cycle as CY
cl = load('../data/closes.csv'); feats, conds = build_all(cl)
FR = [0, .25, .5, .75, 1.0]
def run(coins, a, b, cost):
    out = {f: [] for f in FR}
    for k in coins:
        c = feats[k]['c']; s0 = max(pd.Timestamp(a), c.index[0] + pd.Timedelta(days=200))
        sm = CY.simulate(c, S.composite(conds[k], ['t_ema20_dn']), S.composite(conds[k], ['r_break_high20', 'r_btc_gt20']), s0, pd.Timestamp(b), timeout=60, cost=cost)
        eh = np.cumprod(1 + sm.hold.values); es = np.cumprod(1 + sm.ret.values)
        for f in FR:
            eq = (1 - f) * eh + f * es; pk = np.maximum.accumulate(np.r_[1.0, eq])[1:]
            out[f].append((eq[-1] - 1, (eq / pk - 1).min(), k))
    return out
if __name__ == '__main__':
    rows = []
    for name, coins, (a, b) in (('발견 2018-22 (5종목)', ALTS_LONG, DEV), ('검증 2023-26 (10종목)', ALTS_ALL, VAL)):
        for cost in (0.002, 0.005):
            r = run(coins, a, b, cost)
            for f in FR:
                t = np.array([x[0] for x in r[f]]); m = np.array([x[1] for x in r[f]])
                rows.append(dict(period=name, cost=cost, sell_frac=f, med_total=np.median(t), med_mdd=np.median(m), worst_mdd=m.min(), worst_total=t.min(), beats_hold=np.mean(t > np.array([x[0] for x in r[0]]))))
    R = pd.DataFrame(rows); R.to_csv('../results/partial_sell.csv', index=False); pd.set_option('display.width', 200); print(R.round(3).to_string(index=False))
