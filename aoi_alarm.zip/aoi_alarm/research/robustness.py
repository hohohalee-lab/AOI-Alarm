from cyclelib import *
import json
a, b = map(pd.Timestamp, VAL)
CFG = dict(sell=['t_ema20_dn'], rebuy=['r_break_high20','r_btc_gt20'], timeout=60)
def val_total(cfg, cost=CY.COST, lag=0, coins=ALTS_ALL, start=a, end=b, sell=None):
    sims = {}
    for k in coins:
        c = feats[k]['c']; st = max(start, c.index[0] + pd.Timedelta(days=200))
        sims[k] = CY.simulate(c, S.composite(conds[k], sell or cfg['sell']), S.composite(conds[k], cfg['rebuy']), st, end, timeout=cfg['timeout'], cost=cost, lag=lag)
    sr = pd.DataFrame({k: sims[k]['ret'] for k in coins}).mean(axis=1); hr = pd.DataFrame({k: sims[k]['hold'] for k in coins}).mean(axis=1)
    m, h = CY.metrics(sr.values), CY.metrics(hr.values)
    pc = [CY.metrics(sims[k]['ret'].values)['total'] > CY.metrics(sims[k]['hold'].values)['total'] for k in coins]
    return m['total'], m['mdd'], h['total'], h['mdd'], float(np.mean(pc))
print('== cost / execution-delay sensitivity (validation, pooled) ==')
for cost in (.002, .005, .01):
    for lag in (0, 1, 2):
        t, d, ht, hd, w = val_total(CFG, cost, lag)
        print(f'cost {cost*100:.1f}%/side lag {lag}d : total {t:6.2f} mdd {d:6.2f} | hold {ht:5.2f} {hd:5.2f} | coins beating hold {w:.0%}')
print('== neighbouring sell triggers, same rebuy ==')
for nm, sp in [('ema10_dn',['t_ema10_dn']),('ema20_dn',['t_ema20_dn']),('ema50_dn',['x_ema50_dn']),('low10',['t_low10']),('low20',['t_low20']),('ema_dead',['t_ema_dead'])]:
    t, d, ht, hd, w = val_total(CFG, sell=sp); print(f'{nm:10s} total {t:6.2f} mdd {d:6.2f} coins beating hold {w:.0%}')
print('== neighbouring rebuy, same sell ==')
for nm, rp in [('break20+btc20',['r_break_high20','r_btc_gt20']),('break20',['r_break_high20']),('reclaim20+btc20',['r_reclaim_ema20','r_btc_gt20']),('btc20+rs20',['r_btc_gt20','r_rs_gt20'])]:
    cfg = dict(CFG, rebuy=rp); t, d, ht, hd, w = val_total(cfg); print(f'{nm:16s} total {t:6.2f} mdd {d:6.2f} coins beating hold {w:.0%}')
print('== timeout ==')
for to in (None, 30, 60, 90):
    cfg = dict(CFG, timeout=to); t, d, ht, hd, w = val_total(cfg); print(f'timeout {to}: total {t:6.2f} mdd {d:6.2f} coins beating hold {w:.0%}')
print('== subsamples: only coins with history before 2023 (5 long) vs only 2023+ listings ==')
for nm, cs in [('long5', ALTS_LONG), ('new5', ['SOL','AVAX','NEAR','SUI','ONDO'])]:
    t, d, ht, hd, w = val_total(CFG, coins=cs); print(f'{nm}: total {t:6.2f} mdd {d:6.2f} | hold {ht:5.2f} {hd:5.2f} | coins beating hold {w:.0%}')
print('== dev period same config (informational; selected there) ==')
t, d, ht, hd, w = val_total(CFG, coins=ALTS_LONG, start=pd.Timestamp(DEV[0]), end=pd.Timestamp(DEV[1])); print(f'dev: total {t:6.2f} mdd {d:6.2f} | hold {ht:5.2f} {hd:5.2f} | coins beating hold {w:.0%}')
print('== prefix (look-ahead) test: features/conditions at t must not change when future bars are dropped ==')
cl = load('../data/closes.csv'); bad = 0; tot = 0
for k in ['ETH','SOL','DOGE']:
    for t in pd.to_datetime(['2021-05-10','2024-03-14','2025-10-10','2026-08-20']):
        if t < cl[k].first_valid_index() + pd.Timedelta(days=250): continue
        cut = cl.loc[:t]; f2, c2 = build_all(cut, coins=[k])
        cols = c2[k].columns
        same = (c2[k].loc[t, cols] == conds[k].loc[t, cols]).all(); tot += 1; bad += (not same)
        if not same: print('MISMATCH', k, t, [c for c in cols if c2[k].loc[t, c] != conds[k].loc[t, c]])
print('prefix tests', tot, 'mismatches', bad)
