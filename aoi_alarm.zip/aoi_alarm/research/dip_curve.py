"""Per-1% limit-level curve. For every B sell alarm: if a close <= sell*(1-x) occurs before the usual breakout re-entry date (E), buy there
instead; compare value at E with the plain breakout buyer.  gain = p_E / p_fill - 1 (0 if never filled).  Two fill-price assumptions:
'level' (optimistic: filled exactly at sell*(1-x)) and 'close' (conservative: filled at the closing price that triggered)."""
import pandas as pd, numpy as np
E = pd.read_csv('../results/dip_episodes.csv', parse_dates=['sell', 'B_rebuy_date'])
cl = pd.read_csv('../data/closes.csv', index_col=0, parse_dates=True)
E = E[E.B_rebuy_date.notna()].copy()
XS = np.round(np.arange(0.01, 0.41, 0.01), 2)
rec = []
for r in E.itertuples():
    c = cl[r.coin].dropna(); seg = c.loc[r.sell:r.B_rebuy_date]; pE = seg.iloc[-1]; Ps = r.sell_px; path = seg.iloc[1:-1].values  # closes strictly between sell and re-entry
    for x in XS:
        lv = Ps * (1 - x); hit = np.flatnonzero(path <= lv) if len(path) else []
        if len(hit): pc = path[hit[0]]; rec.append((r.window, r.coin, r.sell, x, 1, pE / lv - 1, pE / pc - 1))
        else: rec.append((r.window, r.coin, r.sell, x, 0, 0.0, 0.0))
R = pd.DataFrame(rec, columns=['window', 'coin', 'sell', 'x', 'filled', 'gain_level', 'gain_close'])
R.to_csv('../results/dip_curve_raw.csv', index=False)
def agg(g):
    f = g[g.filled == 1]
    return pd.Series(dict(n=len(g) , fill=g.filled.mean(), gain_level_mean=g.gain_level.mean(), gain_close_mean=g.gain_close.mean(), gain_close_med_if_filled=f.gain_close.median() if len(f) else np.nan,
                          lose_share_if_filled=(f.gain_close < 0).mean() if len(f) else np.nan, worst_close=f.gain_close.min() if len(f) else np.nan))
S = R.groupby(['window', 'x']).apply(agg).reset_index(); S.to_csv('../results/dip_curve.csv', index=False)
pd.set_option('display.width', 220)
for w in ['2019-21 상승장', '2023-25 상승장', '참고:2026(하락)']:
    s = S[S.window == w]; print(w, 'alarms with a B re-entry:', int(s.n.iloc[0]))
    print(s[s.x.isin([.01, .02, .03, .05, .07, .10, .12, .15, .20, .25, .30])].round(3).drop(columns=['window', 'n']).to_string(index=False))
    b = s.loc[s.gain_close_mean.idxmax()]; print('  best mean gain (conservative fill): x=%.2f fill=%.0f%% gain=%.1f%%' % (b.x, b.fill * 100, b.gain_close_mean * 100))
