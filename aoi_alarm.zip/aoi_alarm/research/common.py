import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import numpy as np, pandas as pd
from aoi import indicators as I, signals as S

ALTS_LONG = ['ETH','XRP','ADA','LINK','DOGE']
ALTS_ALL = ['ETH','XRP','ADA','LINK','DOGE','SOL','AVAX','NEAR','SUI','ONDO']
DEV = ('2018-07-01', '2022-12-31'); VAL = ('2023-01-01', '2026-10-31')

def load(path='data/closes.csv'):
    return pd.read_csv(path, index_col=0, parse_dates=True)

def build_all(closes, coins=ALTS_ALL, universe=None):
    universe = universe or ALTS_ALL
    br = I.breadth_below_ema20(closes[universe])
    feats, conds = {}, {}
    for k in coins:
        c = closes[k].dropna()
        f = I.coin_features(c, closes['BTC'], br)
        feats[k] = f; conds[k] = S.conditions(f)
    return feats, conds
