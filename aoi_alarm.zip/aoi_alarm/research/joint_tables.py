from events import *
cl = load('../data/closes.csv'); feats, conds = build_all(cl)
DEV_EV = ('2018-07-01', '2022-10-01'); VAL_EV = ('2023-01-01', '2026-10-31')
stD = Study(cl, feats, conds, ALTS_LONG); stV = Study(cl, feats, conds, ALTS_ALL)

def active(cond, names, within):
    return pd.DataFrame({n: S.recent(cond[n], within) if within > 1 else cond[n] for n in names})

FAMILIES = {
 # name: (trigger names [any active within N days], N, confirmation names, direction)
 'A_매도온리(국면이탈)': (['x_ema50_dn', 'x_ema100_dn', 'x_dead2050'], 5, ['m_btc_lt50', 'm_btc_dd10', 'm_breadth60'], 'sell'),
 'B_매도(추세이탈)':     (['t_ema20_dn'], 1, ['m_btc_lt20', 'm_breadth60', 'm_rs_lt20'], 'sell'),
 'B_재진입(돌파)':       (['r_break_high20'], 1, ['r_btc_gt20', 'r_rs_gt20', 'r_breadth_ok', 'r_ema20_up'], 'buy'),
}
def level_fn(trig, N, conf, m):
    def fn(cond):
        t = active(cond, trig, N).any(axis=1)
        cnt = active(cond, conf, 1).sum(axis=1)
        return t & (cnt >= m)
    return fn
def events_for(st, fn, period):
    a, b = map(pd.Timestamp, period); ev = []
    for k in st.coins:
        for t in S.events(fn(st.conds[k]), 14):
            if a <= t <= b and not np.isnan(st.fwd[k].at[t, 'r90']): ev.append((k, t))
    return ev
def block_ci(o, col, reps=400, seed=3):
    rng = np.random.default_rng(seed); g = o.groupby(o.date.dt.to_period('M'))[col].agg(['sum', 'count'])
    out = []
    for _ in range(reps):
        i = rng.integers(0, len(g), len(g)); out.append(g['sum'].values[i].sum() / g['count'].values[i].sum())
    return np.percentile(out, [2.5, 97.5])
rows = []
for fam, (trig, N, conf, direction) in FAMILIES.items():
    for split, st, per in (('dev', stD, DEV_EV), ('val', stV, VAL_EV)):
        for m in range(0, len(conf) + 1):
            ev = events_for(st, level_fn(trig, N, conf, m), per)
            if len(ev) < 8: rows.append(dict(family=fam, split=split, k=m, n=len(ev))); continue
            o = st.outcomes(ev); s = summarize(o)
            sims = st.placebo_multi(ev, per, cols=(0, 3, 4, 2), draws=300)     # r30, dn20, up20, r90
            pr30 = (sims[:, 0] <= s['r30']).mean() if direction == 'sell' else (sims[:, 0] >= s['r30']).mean()
            key = 'dn20' if direction == 'sell' else 'up20'; ci = block_ci(o, key)
            s.update(family=fam, split=split, k=m, plc_r30=sims[:, 0].mean(), plc_dn=sims[:, 1].mean(), plc_up=sims[:, 2].mean(), plc_r90=sims[:, 3].mean(),
                     p_r30=pr30, key_prob=o[key].mean(), key_lo=ci[0], key_hi=ci[1],
                     p_key=((sims[:, 1] >= s['dn20']).mean() if direction == 'sell' else (sims[:, 2] >= s['up20']).mean()))
            rows.append(s)
J = pd.DataFrame(rows); J.to_csv('../results/joint_tables.csv', index=False)
pd.set_option('display.width', 280); pd.set_option('display.max_columns', 40)
for fam in FAMILIES:
    d = FAMILIES[fam][3]
    print('\n=====', fam, '(confirmations k = # of flags simultaneously ON; direction:', d, ')')
    cols = ['split', 'k', 'n', 'dates', 'coins', 'r30', 'plc_r30', 'r90', 'plc_r90'] + (['dn20', 'plc_dn'] if d == 'sell' else ['up20', 'plc_up']) + ['key_lo', 'key_hi', 'p_r30', 'p_key']
    print(J[J.family == fam][[c for c in cols if c in J.columns]].round(3).to_string(index=False))
