"""Can the conditions at a B sell alarm tell a big drop (>=30% before the prior peak is reclaimed) from a small wave?
8 conditions declared in advance; look in one window, confirm in the other (both directions)."""
from cyclelib import *
from scipy.stats import fisher_exact
E = pd.read_csv('../results/dip_episodes.csv', parse_dates=['sell'])
cl = load('../data/closes.csv'); feats, conds = build_all(cl, coins=sorted(E.coin.unique()))
def at(r):
    f = feats[r.coin].loc[r.sell]; c = conds[r.coin].loc[r.sell]
    return {'코인<EMA50': f.c < f.ema50, '코인<EMA100': f.c < f.ema100, 'BTC<EMA50': bool(c.m_btc_lt50), 'BTC 60일고점-10%': bool(c.m_btc_dd10),
            '알트60%↓EMA20': bool(c.m_breadth60), '코인 60일고점-20%': f.dd60 <= -0.20, 'RSI<45': f.rsi < 45, '코인/BTC<EMA20': bool(c.m_rs_lt20)}
X = pd.DataFrame([at(r) for r in E.itertuples()]); X['n_weak'] = X.sum(axis=1)
E = pd.concat([E.reset_index(drop=True), X], axis=1); E['big'] = E.trough_vs_sell <= -0.30; E['big20'] = E.trough_vs_sell <= -0.20
E.to_csv('../results/big_vs_small_data.csv', index=False)
conds_n = list(X.columns[:-1]) + ['n_weak>=3', 'n_weak>=5']
E['n_weak>=3'] = E.n_weak >= 3; E['n_weak>=5'] = E.n_weak >= 5
rows = []
for w in ['2019-21 상승장', '2023-25 상승장', '참고:2026(하락)']:
    g = E[E.window == w]
    for cnd in conds_n:
        a = g[g[cnd]]; b = g[~g[cnd]]
        if len(a) < 8 or len(b) < 8: rows.append(dict(window=w, cond=cnd, n_yes=len(a), n_no=len(b))); continue
        p = fisher_exact([[a.big.sum(), len(a) - a.big.sum()], [b.big.sum(), len(b) - b.big.sum()]])[1]
        rows.append(dict(window=w, cond=cnd, share_yes=len(a) / len(g), n_yes=len(a), big_yes=a.big.mean(), n_no=len(b), big_no=b.big.mean(), diff=a.big.mean() - b.big.mean(), p=p,
                         med_tr_yes=a.trough_vs_sell.median(), med_tr_no=b.trough_vs_sell.median()))
R = pd.DataFrame(rows); R.to_csv('../results/big_vs_small.csv', index=False)
pd.set_option('display.width', 250); print(R.round(3).to_string(index=False))
print('base big rate:', E.groupby('window').big.mean().round(3).to_dict())
