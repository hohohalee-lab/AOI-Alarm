"""Hindsight view: where did swing lows (lowest close of +-10 days, after >=15% fall from the prior 30-day high) happen, and how well does each chart condition 'point at' them?"""
import sys; sys.argv = ['x']
exec(open('bottom_scan.py').read().split("PER = {")[0])   # reuse candidate construction
def swing_lows(c):
    lo = c.rolling(21, center=True).min() == c; prior = c.rolling(31).max().shift(1)
    return lo & (c / prior - 1 <= -0.15)
rows = []
for pn, coins, (a, b) in (('발견 2018-22', ALTS_LONG, ('2018-07-01', '2022-10-01')), ('검증 2023-26', ALTS_ALL, ('2023-01-01', '2026-07-01'))):
    for nm in ['RSI<30', 'RSI<25', '볼린저 하단 이탈', 'EMA20 대비 -15%↓', '60일고점 -30%↓', '7일 -20%↓', '5일 연속 하락', '10일 저점 상승(higher low)']:
        nl = hit = ne = ev_ok = base_n = base_ok = 0
        for k in coins:
            c = feats[k].c.loc[a:b]; sl = swing_lows(feats[k].c).loc[a:b]; cond = conds[k][nm].loc[a:b]
            idx = c.index; slv = sl.values; cv = cond.values
            nl += slv.sum()
            for i in np.flatnonzero(slv):
                hit += cv[max(0, i - 5):i + 1].any()
            ev = S.events(cond, 10); evi = [idx.get_loc(t) for t in ev if t in idx and idx.get_loc(t) < len(idx) - 11]
            ne += len(evi); ev_ok += sum(slv[i:i + 11].any() for i in evi)
            allp = range(0, len(idx) - 11); base_n += len(allp); base_ok += sum(slv[i:i + 11].any() for i in allp)
        rows.append(dict(period=pn, cond=nm, swing_lows=int(nl), recall=hit / nl, signals=ne, precision=ev_ok / ne if ne else np.nan, random_day_rate=base_ok / base_n))
R = pd.DataFrame(rows); R.to_csv('../results/bottom_hindsight.csv', index=False); pd.set_option('display.width', 200); print(R.round(3).to_string(index=False))
# base rate among days already >=15% below their prior 30-day high (the mechanical condition shared by the labels)
for pn, coins, (a, b) in (('발견 2018-22', ALTS_LONG, ('2018-07-01', '2022-10-01')), ('검증 2023-26', ALTS_ALL, ('2023-01-01', '2026-07-01'))):
    n = ok = fd = 0
    for k in coins:
        c = feats[k].c; sl = swing_lows(c).values; m = (c / c.rolling(31).max().shift(1) - 1 <= -0.15).values
        idx = c.index; lo, hi = idx.get_loc(c.loc[a:b].index[0]), idx.get_loc(c.loc[a:b].index[-1]) - 11
        for i in range(lo, hi):
            if m[i]:
                n += 1; ok += sl[i:i + 11].any(); fd += (c.values[i + 1:i + 61].min() / c.values[i] - 1 <= -0.10)
    print(pn, 'days >=15% below prior 30d high:', n, ' swing low within next 10d:', round(ok / n, 3), ' further >=10% drop within 60d:', round(fd / n, 3))
