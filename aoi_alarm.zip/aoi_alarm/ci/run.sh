#!/usr/bin/env bash
# Runs inside GitHub Actions after `unzip -qo aoi_alarm.zip -d _app`. Keeps repo root tiny: aoi_alarm.zip + watchlist.json + docs/ + state/.
set -euo pipefail
WS="${GITHUB_WORKSPACE:-$PWD}"; APP="$WS/_app/aoi_alarm"
cd "$WS"
python -m pip install -q -r "$APP/requirements.txt"
[ -f watchlist.json ] || cp "$APP/config/watchlist.json" watchlist.json       # user-editable watchlist lives in the repo root
mkdir -p docs state
tar -C "$APP/docs" --exclude=./data -cf - . | tar -C docs -xf -                # refresh app shell, keep data/
mkdir -p docs/data
export PYTHONPATH="$APP" AOI_CONFIG="$WS/watchlist.json" AOI_STATE_DIR="$WS/state" AOI_DOCS_DIR="$WS/docs"
if [ "${TEST_NOTIFY:-false}" = "true" ]; then python -m aoi.app test-notify; fi
python -m aoi.app run
